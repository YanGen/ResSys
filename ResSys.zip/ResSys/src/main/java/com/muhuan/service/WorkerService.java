package com.muhuan.service;

import com.muhuan.dao.*;

import com.muhuan.model.school.Worker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @author young
 * @ClassName: WorkerService
 * @Description: TODO()
 * @date 2018/10/26 9:51
 */
@Service("workerService")
@Transactional
public class WorkerService {
    @Autowired
    private WorkerDaoImpl workerDao;



    public List<Worker> getWorkerList() {
        return (List<Worker>) workerDao.getHibernateTemplate().find("From Worker");
    }

    public List<Worker> findWorkerList(String name) {
        Worker worker = new Worker();
        worker.setName(name);
        return (List<Worker>) workerDao.getHibernateTemplate().findByExample(worker);
    }

    @Transactional
    public void deleteWorkerByID(Integer id) {
        Worker worker = workerDao.getById(id);
        workerDao.delete(worker);
    }

    @Transactional
    public void updateWorkerByID(Worker worker) {
        workerDao.update(worker);
    }

    @Transactional
    public void saveWorkerList(Worker worker) {
        workerDao.save(worker);
    }

    public Worker getWorkerById(Integer id) {
        return workerDao.getById(id);
    }
}
