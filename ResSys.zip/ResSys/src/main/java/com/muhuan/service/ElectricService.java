package com.muhuan.service;

import com.google.gson.*;
import com.muhuan.utils.json.HistoryTradeBean;
import com.muhuan.utils.json.MapAreaIdBean;
import com.muhuan.utils.json.MapResultBean;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.springframework.stereotype.Service;

import java.nio.charset.Charset;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

/**
 * @author young
 * @ClassName: ElectricService
 * @Description: TODO()
 * @date 2019/2/24 17:11
 */
@Service
public class ElectricService {

    public String mapAreaId(String repairArea3) {
        String params = "areaId=1";
        String url = "http://axf.nfu.edu.cn/electric/getData/getArchitectures";
        HttpClient httpClient = null;
        HttpPost postMethod = null;
        HttpResponse response = null;
        try {
            httpClient = HttpClients.createDefault();
            postMethod = new HttpPost(url);//传入URL地址
            //设置请求头
            postMethod.addHeader("Content-type", "application/x-www-form-urlencoded; charset=UTF-8");
            postMethod.addHeader("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36 MicroMessenger/6.5.2.501 NetType/WIFI WindowsWechat QBCore/3.43.901.400 QQBrowser/9.0.2524.400");
            postMethod.addHeader("X-Requested-With", "XMLHttpRequest");//设置请求头
            //传入请求参数
            postMethod.setEntity(new StringEntity(params, Charset.forName("UTF-8")));
            response = httpClient.execute(postMethod);//获取响应
            int statusCode = response.getStatusLine().getStatusCode();
            System.out.println("HTTP Status Code:" + statusCode);
            if (statusCode != HttpStatus.SC_OK) {
                System.out.println("HTTP请求未成功！HTTP Status Code:" + response.getStatusLine());
            }
            HttpEntity httpEntity = response.getEntity();
            String reponseContent = EntityUtils.toString(httpEntity);
            EntityUtils.consume(httpEntity);//释放资源
            Gson gson = new Gson();
            JsonObject jsonObject = (JsonObject) new JsonParser().parse(reponseContent);
            JsonArray jsonArray = jsonObject.get("data").getAsJsonArray();
            Iterator it = jsonArray.iterator();
            while(it.hasNext()){
                JsonElement e = (JsonElement)it.next();
                //JsonElement转换为JavaBean对象
                MapAreaIdBean mapAreaIdBean = gson.fromJson(e,MapAreaIdBean.class);
                if(mapAreaIdBean.getValue().contains(repairArea3.replace("教师宿舍","聚贤楼").replace("学生宿舍","学楼").replace("-1-","").replace("-2-","")+"号")){
                    return mapAreaIdBean.getKey();
                }

            }



        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public String mapRoomId(String architectureId, String repairArea4) {
        String params = "areaId=1&architectureId="+architectureId+"&floorId="+repairArea4.substring(0,1);
        String url = "http://axf.nfu.edu.cn/electric/getData/getRooms";
        HttpClient httpClient = null;
        HttpPost postMethod = null;
        HttpResponse response = null;
        try {
            httpClient = HttpClients.createDefault();
            postMethod = new HttpPost(url);//传入URL地址
            //设置请求头
            postMethod.addHeader("Content-type", "application/x-www-form-urlencoded; charset=UTF-8");
            postMethod.addHeader("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36 MicroMessenger/6.5.2.501 NetType/WIFI WindowsWechat QBCore/3.43.901.400 QQBrowser/9.0.2524.400");
            postMethod.addHeader("X-Requested-With", "XMLHttpRequest");//设置请求头
            //传入请求参数
            postMethod.setEntity(new StringEntity(params, Charset.forName("UTF-8")));
            response = httpClient.execute(postMethod);//获取响应
            int statusCode = response.getStatusLine().getStatusCode();
            System.out.println("HTTP Status Code:" + statusCode);
            if (statusCode != HttpStatus.SC_OK) {
                System.out.println("HTTP请求未成功！HTTP Status Code:" + response.getStatusLine());
            }
            HttpEntity httpEntity = response.getEntity();
            String reponseContent = EntityUtils.toString(httpEntity);
            EntityUtils.consume(httpEntity);//释放资源
            Gson gson = new Gson();
            JsonObject jsonObject = (JsonObject) new JsonParser().parse(reponseContent);
            JsonArray jsonArray = jsonObject.get("data").getAsJsonArray();
            Iterator it = jsonArray.iterator();
            while(it.hasNext()){
                JsonElement e = (JsonElement)it.next();
                //JsonElement转换为JavaBean对象
                MapAreaIdBean mapAreaIdBean = gson.fromJson(e,MapAreaIdBean.class);
                if(mapAreaIdBean.getValue().contains(repairArea4)){
                    return mapAreaIdBean.getKey();
                }

            }



        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public String searchCurrent(String roomId) {
        String params = "roomId="+roomId;
        String url = "http://axf.nfu.edu.cn/electric/getData/getReserveAM";
        HttpClient httpClient = null;
        HttpPost postMethod = null;
        HttpResponse response = null;
        try {
            httpClient = HttpClients.createDefault();
            postMethod = new HttpPost(url);//传入URL地址
            //设置请求头
            postMethod.addHeader("Content-type", "application/x-www-form-urlencoded; charset=UTF-8");
            postMethod.addHeader("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36 MicroMessenger/6.5.2.501 NetType/WIFI WindowsWechat QBCore/3.43.901.400 QQBrowser/9.0.2524.400");
            postMethod.addHeader("X-Requested-With", "XMLHttpRequest");//设置请求头
            //传入请求参数
            postMethod.setEntity(new StringEntity(params, Charset.forName("UTF-8")));
            response = httpClient.execute(postMethod);//获取响应
            int statusCode = response.getStatusLine().getStatusCode();
            System.out.println("HTTP Status Code:" + statusCode);
            if (statusCode != HttpStatus.SC_OK) {
                System.out.println("HTTP请求未成功！HTTP Status Code:" + response.getStatusLine());
            }
            HttpEntity httpEntity = response.getEntity();
            String reponseContent = EntityUtils.toString(httpEntity);
            EntityUtils.consume(httpEntity);//释放资源
            Gson gson = new Gson();
            JsonObject jsonObject = (JsonObject) new JsonParser().parse(reponseContent);
            return jsonObject.get("data").getAsJsonObject().get("remainPower").getAsString();


        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<HistoryTradeBean> searchHistory(String roomId) {
        String params = "pageSize=30&pageIndex=1&ammeterId="+roomId;
        String url = "http://axf.nfu.edu.cn/electric/order/page";
        HttpClient httpClient = null;
        HttpPost postMethod = null;
        HttpResponse response = null;
        try {
            httpClient = HttpClients.createDefault();
            postMethod = new HttpPost(url);//传入URL地址
            //设置请求头
            postMethod.addHeader("Content-type", "application/x-www-form-urlencoded; charset=UTF-8");
            postMethod.addHeader("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36 MicroMessenger/6.5.2.501 NetType/WIFI WindowsWechat QBCore/3.43.901.400 QQBrowser/9.0.2524.400");
            postMethod.addHeader("X-Requested-With", "XMLHttpRequest");//设置请求头
            //传入请求参数
            postMethod.setEntity(new StringEntity(params, Charset.forName("UTF-8")));
            response = httpClient.execute(postMethod);//获取响应
            int statusCode = response.getStatusLine().getStatusCode();
            System.out.println("HTTP Status Code:" + statusCode);
            if (statusCode != HttpStatus.SC_OK) {
                System.out.println("HTTP请求未成功！HTTP Status Code:" + response.getStatusLine());
            }
            HttpEntity httpEntity = response.getEntity();
            String reponseContent = EntityUtils.toString(httpEntity);
            EntityUtils.consume(httpEntity);//释放资源
            Gson gson = new Gson();
            JsonObject jsonObject = (JsonObject) new JsonParser().parse(reponseContent);
            JsonArray jsonArray = jsonObject.get("data").getAsJsonObject().get("rows").getAsJsonArray();
            Iterator it = jsonArray.iterator();

            List<HistoryTradeBean> historyTrades = new LinkedList<>();

            while(it.hasNext()){
                JsonElement e = (JsonElement)it.next();
                //JsonElement转换为JavaBean对象
                HistoryTradeBean historyTrade = gson.fromJson(e,HistoryTradeBean.class);
                historyTrades.add(historyTrade);

            }
            return historyTrades;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
