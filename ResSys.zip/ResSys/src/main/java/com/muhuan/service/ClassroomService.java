package com.muhuan.service;

import com.muhuan.dao.BuildingDaoImpl;
import com.muhuan.dao.ClassroomApplySheetDaoImpl;
import com.muhuan.model.flow.ClassroomApplySheet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;
import java.util.Map;

@Service
@Transactional
public class ClassroomService {

    @Autowired
    private BuildingDaoImpl buildingDao;
    @Autowired
    private ClassroomApplySheetDaoImpl classroomApplySheetDao;

    public Boolean checkClassroomTimeAllow(Date startTime, Date endTime, String buildId,String buildNumber) {
        if(endTime.getTime() <= startTime.getTime()|| endTime.getTime() < new Date().getTime()){
           return false;
        }
//        检查是否时间 冲突
        ClassroomApplySheet classroomApplySheet = new ClassroomApplySheet();
        classroomApplySheet.setBuilding(buildingDao.getById(Integer.valueOf(buildId)));
        classroomApplySheet.setBuildingNumber(buildNumber);

        List<ClassroomApplySheet> classroomApplySheets = classroomApplySheetDao.getByObject(classroomApplySheet);
        for(ClassroomApplySheet classroomApplySheet1 : classroomApplySheets){
            if(classroomApplySheet1.getResult() == null || classroomApplySheet1.getResult().equals("通过")){
                if(classroomApplySheet1.getStartTime().getTime()>=endTime.getTime()){

                }else if (classroomApplySheet1.getEndTime().getTime()<=startTime.getTime()){

                }else {
                    return false;
                }
            }

        }
        return true;
    }
}
