package com.muhuan.service;

import com.muhuan.dao.GlobalDaoImpl;
import com.muhuan.dao.LogisticsRepairSheetDaoImpl;
import com.muhuan.model.flow.LogisticsRepairSheet;
import com.muhuan.model.school.Global;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

/**
 * @author young
 * @ProjectName: ResSys
 * @Description: TODO()
 * @date 2018/12/9 19:50
 */
@Service
@Transactional
public class RepairService {

    @Autowired
    private LogisticsRepairSheetDaoImpl logisticsRepairSheetDao;
    @Autowired
    private GlobalDaoImpl globalDao;

    public void applyLogisticsRepairSheet(LogisticsRepairSheet logisticsRepairSheet) {
        logisticsRepairSheet.setApplyTime(new Date());
        logisticsRepairSheetDao.save(logisticsRepairSheet);
    }

    public void applySchoolRepairSheet(Global global) {
        globalDao.save(global);
    }

    public List<LogisticsRepairSheet> workerRepairSheetList() {
        return logisticsRepairSheetDao.workerRepairSheetList();
    }
}
