package com.muhuan.service;

import com.muhuan.dao.CourseDaoImpl;
import com.muhuan.dao.EvaluationCardDaoImpl;
import com.muhuan.model.basic.Course;
import com.muhuan.model.flow.DeviceApplySheet;
import com.muhuan.model.school.Student;
import com.muhuan.model.util.Pager;
import ognl.Evaluation;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author young
 * @ProjectName: ResSys
 * @Description: TODO()
 * @date 2018/11/19 12:39
 */
@Service
public class EvaluationService {


}
