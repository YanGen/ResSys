package com.muhuan.service;

import com.muhuan.dao.*;
import com.muhuan.model.basic.Dormitory;
import com.muhuan.model.flow.DeviceApplySheet;
import com.muhuan.model.flow.DormExchangeSheet;
import com.muhuan.model.school.Building;
import com.muhuan.model.school.Student;
import com.muhuan.model.util.Pager;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Service("dormService")
@Transactional
public class DormService {
    @Autowired
    private DormitoryDaoImpl dormitoryDao;
    @Autowired
    private BuildingDaoImpl buildingDao;
    @Autowired
    private DormExchangeSheetDaoImpl dormExchangeSheetDao;
    @Autowired
    private StudentDao studentDao;

    public List<DormExchangeSheet> notProveDormExchangeApplyList(Pager<DormExchangeSheet> pager) {
        DetachedCriteria detachedCriteria = DetachedCriteria.forClass(DormExchangeSheet.class);
        detachedCriteria.setResultTransformer(DetachedCriteria.DISTINCT_ROOT_ENTITY);
        detachedCriteria.add(Restrictions.isNull("teacherCode"));
        return dormExchangeSheetDao.getList(detachedCriteria,pager.getStart(),pager.getPageSize());
    }

    public void registerDormitory(Student student, String buildId, String buildNumber, String repairArea4) {
        if (student.getDormitory()!=null){
            return;
        }
        List<Dormitory> dormitories = dormitoryDao.getByItem(buildId,buildNumber,repairArea4);
        List<Student> students = new ArrayList<>();
        if(dormitories.size() != 0){
            Dormitory dormitory = dormitories.get(0);
            students = dormitory.getStudents();
            students.add(student);
            dormitory.setStudents(students);
            dormitoryDao.update(dormitory);
        }else {
            Dormitory dormitory = new Dormitory();

            Building building = buildingDao.getById(Integer.valueOf(buildId));
            dormitory.setBuilding(building);
            dormitory.setRoomNumber(repairArea4);
            dormitory.setBuildingNumber(buildNumber);
            student.setDormitory(dormitory);
            dormitory.getStudents().add(student);
            dormitoryDao.save(dormitory);

        }

    }

    public void applyExchangeDormitory(Student student, String buildId, String buildNumber, String repairArea4,String oldArea1) {
        if (student.getDormitory()==null){
            return;
        }

        DormExchangeSheet dormExchangeSheet = new DormExchangeSheet();
        dormExchangeSheet.setApplyTime(new Date());
        dormExchangeSheet.setNewBuilding(buildingDao.getById(Integer.valueOf(buildId)));
        dormExchangeSheet.setNewBuildingNumber(buildNumber);
        dormExchangeSheet.setNewBuildingRoomNumber(repairArea4);
        dormExchangeSheet.setOldDormitory(oldArea1);
        dormExchangeSheet.setStudentId(student.getSid());
        dormExchangeSheet.setStudentName(student.getName());

        dormExchangeSheetDao.save(dormExchangeSheet);

    }

    public void exchangeStudentDormitory(Integer sheetId,String teacherCode) {
        DormExchangeSheet dormExchangeSheet = dormExchangeSheetDao.getById(sheetId);
        Student student = studentDao.getById(dormExchangeSheet.getStudentId());

        List<Dormitory> dormitories = dormitoryDao.getByItem(String.valueOf(dormExchangeSheet.getNewBuilding().getId()),dormExchangeSheet.getNewBuildingNumber(),dormExchangeSheet.getNewBuildingRoomNumber());
        if(dormitories.size() != 0){
            Dormitory dormitory = dormitories.get(0);
            student.setDormitory(dormitory);
            studentDao.update(student);
        }else {
            Dormitory dormitory = new Dormitory();

            dormitory.setBuilding(dormExchangeSheet.getNewBuilding());
            dormitory.setRoomNumber(dormExchangeSheet.getNewBuildingRoomNumber());
            dormitory.setBuildingNumber(dormExchangeSheet.getNewBuildingNumber());
            student.setDormitory(dormitory);
            dormitory.getStudents().add(student);
            dormitoryDao.save(dormitory);

        }
        dormExchangeSheet.setAdminHasProve(true);
        dormExchangeSheet.setProveTime(new Date());
        dormExchangeSheet.setApplyResult("批准");
        dormExchangeSheet.setTeacherCode(teacherCode);
        dormExchangeSheetDao.update(dormExchangeSheet);
    }

    public void disExchangeStudentDormitory(Integer sheetId,String teacherCode) {
        DormExchangeSheet dormExchangeSheet = dormExchangeSheetDao.getById(sheetId);
        dormExchangeSheet.setApplyResult("不同意");
        dormExchangeSheet.setProveTime(new Date());
        dormExchangeSheet.setAdminHasProve(false);
        dormExchangeSheet.setTeacherCode(teacherCode);
        dormExchangeSheetDao.update(dormExchangeSheet);
    }
}
