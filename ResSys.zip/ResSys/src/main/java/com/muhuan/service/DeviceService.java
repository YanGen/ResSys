package com.muhuan.service;

import com.muhuan.dao.DeviceApplySheetDaoImpl;
import com.muhuan.dao.DeviceDao;
import com.muhuan.dao.DeviceDaoImpl;
import com.muhuan.model.basic.Device;
import com.muhuan.model.util.Pager;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projections;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @author young
 * @ClassName: DeviceService
 * @Description: TODO()
 * @date 2018/10/18 20:10
 */
@Service("deviceService")
@Transactional(readOnly = true)
public class DeviceService {
    @Autowired
    private DeviceDaoImpl deviceDao;
    @Autowired
    private DeviceApplySheetDaoImpl deviceApplySheetDao;
    public List<Device> list(Pager<Device> devicePager){
        DetachedCriteria detachedCriteria = DetachedCriteria.forClass(Device.class);
        detachedCriteria.setResultTransformer(DetachedCriteria.DISTINCT_ROOT_ENTITY);
        return deviceDao.getList(detachedCriteria,devicePager.getStart(),devicePager.getPageSize());
    }


    // 业务待完善
    public Boolean apply(Integer deviceId,Integer studentId,Integer num){
        return true;
    }

    @Transactional
    public void update(Device device){
        deviceDao.update(device);
    }
    @Transactional
    public Device getById(Integer deviceId){
        Device device = deviceDao.getById(deviceId);
        return device;
    }
    @Transactional
    public void delete(Integer t){
        deviceDao.delete(t);
    }
    @Transactional
    public void saveOne(Device device){
        deviceDao.save(device);
    }

    public Integer total() {
        DetachedCriteria detachedCriteria = DetachedCriteria.forClass(Device.class);
        Integer total = deviceDao.getTotalCount(detachedCriteria);
        return total;
    }
}
