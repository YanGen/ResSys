package com.muhuan.service;

import com.muhuan.dao.*;
import com.muhuan.model.basic.Course;
import com.muhuan.model.basic.Device;
import com.muhuan.model.flow.*;
import com.muhuan.model.school.Department;
import com.muhuan.model.school.Major;
import com.muhuan.model.school.Student;
import com.muhuan.model.school.Teacher;
import com.muhuan.model.util.Pager;
import com.muhuan.utils.security.VoucherUtil;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

/**
 * @author young
 * @ClassName: TeacherAdminService
 * @Description: TODO()
 * @date 2018/10/26 11:48
 */
@Service("teacherAdminService")
@Transactional
public class TeacherAdminService {
    @Autowired
    private CourseDaoImpl courseDao;
    @Autowired
    private TeacherDaoImpl teacherDao;
    @Autowired
    private StudentDaoImpl studentDao;
    @Autowired
    private MajorDaoImpl majorDao;
    @Autowired
    private DeviceApplySheetDaoImpl deviceApplySheetDao;
    @Autowired
    private DeviceApplyReceiptSheetDaoImpl deviceApplyReceiptSheetDao;
    @Autowired
    private DepartmentDaoImpl departmentDao;
    @Autowired
    private DeviceDaoImpl deviceDao;
    @Autowired
    private ClassroomApplySheetDaoImpl classroomApplySheetDao;
    @Autowired
    private DormExchangeSheetDaoImpl dormExchangeSheetDao;
    @Autowired
    private LogisticsRepairSheetDaoImpl logisticsRepairSheetDao;

    public List<DeviceApplySheet> getProveDeviceApplyList(Pager<DeviceApplySheet> pager) {
        DetachedCriteria detachedCriteria = DetachedCriteria.forClass(DeviceApplySheet.class);
        detachedCriteria.setResultTransformer(DetachedCriteria.DISTINCT_ROOT_ENTITY);
        detachedCriteria.add(Restrictions.or(Restrictions.eq("hasProve",true),Restrictions.isNull("teacherCode")));
        detachedCriteria.add(Restrictions.eq("adminHasProve",false));
        return deviceApplySheetDao.getList(detachedCriteria,pager.getStart(),pager.getPageSize());
    }

    public Boolean proveDeviceApply(Integer sheetId,Date voucherDate,String illustrate,Integer allowNum,DeviceApplyReceiptSheet deviceApplyReceiptSheet){
        DeviceApplySheet deviceApplySheet = deviceApplySheetDao.getById(sheetId);
        Device device = deviceApplySheet.getDevice();
        if(allowNum>device.getMargin()){
            return false;
        }
        if(! allowNum.equals(deviceApplySheet.getApplyNum())){
            deviceApplyReceiptSheet.setResult("修改");
        }
        if(deviceApplySheet.getTeacherCode() != null){
            if (!deviceApplySheet.getHasProve()){
                return false;
            }
        }
        deviceApplyReceiptSheet.setVoucherDate(voucherDate);
        deviceApplyReceiptSheet.setAllowNumber(allowNum);
        deviceApplyReceiptSheet.setIllustrate(illustrate);
        deviceApplyReceiptSheet.setDeviceApplySheet(deviceApplySheet);
        device.setMargin(device.getMargin() - allowNum);
        deviceDao.update(device);
        deviceApplyReceiptSheet.setVoucher(VoucherUtil.generateVoucher(""));
        deviceApplyReceiptSheetDao.save(deviceApplyReceiptSheet);
        deviceApplySheet.setAdminHasProve(true);
        deviceApplySheetDao.update(deviceApplySheet);

        return true;
    }

    public void disproveDeviceApply(Integer sheetId,String illustrate, DeviceApplyReceiptSheet deviceApplyReceiptSheet){
        DeviceApplySheet deviceApplySheet = deviceApplySheetDao.getById(sheetId);
        deviceApplyReceiptSheet.setIllustrate(illustrate);
        deviceApplyReceiptSheet.setDeviceApplySheet(deviceApplySheet);
        deviceApplyReceiptSheetDao.save(deviceApplyReceiptSheet);
        deviceApplySheet.setAdminHasProve(true);
        deviceApplySheetDao.delete(deviceApplySheet);
    }

    public void startEvaluation(Integer courseId){
        Course c = courseDao.getById(courseId);

        for(Student s : c.getStudents()){
            s.getHasNotEvaluationCourses().add(c);
            studentDao.update(s);
        }

        c.setStartEvaluation(true);
        courseDao.update(c);
    }

    public void addDepartment(Department department) {
        departmentDao.save(department);
    }

    public void addMajor(Major major,Integer d) {
        major.setDepartment(departmentDao.getById(d));
        majorDao.save(major);
    }

    public void addStudent(Student student, Integer MajorId,Integer courseId) {
        student.setMajor(majorDao.getById(MajorId));
        Set<Course> courses = student.getCourses();
        courses.add(courseDao.getById(courseId));
        student.setCourses(courses);
        studentDao.save(student);
    }

    public void addTeacher(Teacher teacher, Integer i) {
        teacher.setMajor(majorDao.getById(i));
        teacherDao.save(teacher);
    }

    public List<String> addCourse(Course course, Integer teacherId, List<String> stuNumList) {
        List<String> err = new ArrayList<>();
        Set<Student> students = new HashSet<>();
        for(String stuNum : stuNumList){
            Student student = studentDao.getByStudentNumber(stuNum);
            if (student == null) {
                err.add(stuNum);
                continue;
            }
            student.getCourses().add(course);
            studentDao.update(student);
            boolean res = students.add(student);
            System.out.println(res);
        }
        course.setStudents(students);
        course.setTeacher(teacherDao.getById(teacherId));

        courseDao.save(course);
        return err;
    }

    public List<ClassroomApplySheet> getProveClassroomApplyList(Pager<ClassroomApplySheet> sheetPager) {
        DetachedCriteria detachedCriteria = DetachedCriteria.forClass(ClassroomApplySheet.class);
        detachedCriteria.setResultTransformer(DetachedCriteria.DISTINCT_ROOT_ENTITY);
        detachedCriteria.add(Restrictions.or(Restrictions.eq("hasProve",true),Restrictions.isNull("teacherCode")));
        detachedCriteria.add(Restrictions.eq("adminHasProve",false));
        return classroomApplySheetDao.getList(detachedCriteria,sheetPager.getStart(),sheetPager.getPageSize());
    }

    public void disproveClassroomApply(Integer sheetId, String illustrate, Teacher teacher) {
        ClassroomApplySheet classroomApplySheet = classroomApplySheetDao.getById(sheetId);
        classroomApplySheet.setAdminHasProve(true);
        classroomApplySheet.setResult("不通过");
        classroomApplySheet.setTeacherName(teacher.getName());
        classroomApplySheet.setTeacherId(String.valueOf(teacher.getId()));
        classroomApplySheet.setTeacherCode(teacher.getTeacherCode());

        classroomApplySheet.setIllustrate(illustrate);
        classroomApplySheetDao.update(classroomApplySheet);
    }

    public Boolean proveClassroomApply(Integer sheetId,String illustrate,String teacherName,String teacherId) {

        ClassroomApplySheet classroomApplySheet = classroomApplySheetDao.getById(sheetId);

        classroomApplySheet.setIllustrate(illustrate);
        classroomApplySheet.setResult("批准");
        classroomApplySheet.setTeacherName(teacherName);
        classroomApplySheet.setTeacherId(teacherId);
        classroomApplySheet.setAdminHasProve(true);
        classroomApplySheetDao.update(classroomApplySheet);
        return true;
    }

    public ClassroomApplySheet getClassroomApplySheet(Integer id) {
        return  classroomApplySheetDao.getById(id);

    }

        public DormExchangeSheet getDormExchangeSheet(Integer id) {
        return  dormExchangeSheetDao.getById(id);

    }

        public LogisticsRepairSheet getLogisticsRepairSheet(Integer id) {
        return  logisticsRepairSheetDao.getById(id);

    }
}
