package com.muhuan.service;

import com.muhuan.dao.*;
import com.muhuan.model.basic.Course;
import com.muhuan.model.basic.EvaluationCard;
import com.muhuan.model.flow.ClassroomApplySheet;
import com.muhuan.model.flow.DeviceApplySheet;
import com.muhuan.model.flow.DormExchangeSheet;
import com.muhuan.model.flow.LogisticsRepairSheet;
import com.muhuan.model.school.Student;
import com.muhuan.model.util.Pager;
import com.muhuan.model.util.UploadFile;
import ognl.Evaluation;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

/**
 * @author young
 * @ClassName: StudentService
 * @Description: TODO()
 * @date 2018/10/24 15:13
 */
@Service("studentService")
@Transactional(readOnly = false)
public class StudentService {
    @Autowired
    private StudentDaoImpl studentDao;
    @Autowired
    private DeviceApplySheetDaoImpl deviceApplySheetDao;
    @Autowired
    private CourseDaoImpl courseDao;
    @Autowired
    private EvaluationItemDaoImpl evaluationItemDao;
    @Autowired
    private EvaluationCardDaoImpl evaluationCardDao;
    @Autowired
    private DormitoryDaoImpl dormitoryDao;
    @Autowired
    private BuildingDaoImpl buildingDao;
    @Autowired
    private ClassroomApplySheetDaoImpl classroomApplySheetDao;
    @Autowired
    private DormExchangeSheetDaoImpl dormExchangeSheetDao;
    @Autowired
    private LogisticsRepairSheetDaoImpl logisticsRepairSheetDao;
    @Autowired
    private UploadFileDaoImpl uploadFileDao;

    public void registDormitory(){

    }

    public List<Course> getEvaluationCourseListByStudentAndPager(Student curStudent, Pager<Course> pager) {
        DetachedCriteria detachedCriteria = DetachedCriteria.forClass(Evaluation.class);
        detachedCriteria.setResultTransformer(DetachedCriteria.DISTINCT_ROOT_ENTITY);
        detachedCriteria.add(Restrictions.or(Restrictions.eq("hasProve",true),Restrictions.isNull("teacherCode")));
        detachedCriteria.add(Restrictions.eq("adminHasProve",false));
        return courseDao.getList(detachedCriteria,pager.getStart(),pager.getPageSize());
    }
    @Transactional
    public void generateDeviceApplySheet(DeviceApplySheet deviceApplySheet){
        deviceApplySheetDao.save(deviceApplySheet);
    }



    public Set<Course> curStudentEvaluationCourseList(Student student) {

        Student student1 = studentDao.getById(student.getSid());

        return student1.getHasNotEvaluationCourses();
    }

    public Set<Course> curStudentCourseList(Student curStudent) {
        Student student1 = studentDao.getByStudentNumber(curStudent.getStudentCode());

        return student1.getCourses();
    }

    public Course getEvaluationCourseById(Integer cid) {
        return courseDao.getById(cid);
    }

    public EvaluationCard getEvaluationCardWithCourseInfo(Integer courseId) {
        Course course = courseDao.getById(courseId);
        EvaluationCard evaluationCard = new EvaluationCard();
        evaluationCard.setCourse(course);
        evaluationCard.setEvaluationItems(evaluationItemDao.getAll());
        evaluationCard.setTeacher(course.getTeacher());
        return evaluationCard;
    }
    @Transactional
    public Boolean evaluationCardCheck(EvaluationCard evaluationCard, Course evaluationCourse,Student student, String[] itemScore) {
        student = studentDao.getById(student.getSid());
        Boolean point = false;
        if (itemScore.length != evaluationItemDao.getAll().size()){
            return false;
        }
        if (!evaluationCourse.getStartEvaluation()){
            return false;
        }
        for (Student student1: evaluationCourse.getStudents()){
            if (student.getSid().equals(student1.getSid())){
                point = true;
                student1.setSid(null);
                break;
            }
        }
        if (!point){
            return false;
        }
        point = false;
        for (Course course1 : student.getHasNotEvaluationCourses()){
            if (course1.getCid().equals(evaluationCourse.getCid())){
                point = true;
                break;
            }
        }
        if (!point){
            return false;
        }
        evaluationCard.setScoreList(StringUtils.join(itemScore,","));

        Set<Course> studentHasNotEvaluationCourses = student.getHasNotEvaluationCourses();
        for (Course courseItem : studentHasNotEvaluationCourses){
            if (courseItem.getCid().equals(evaluationCourse.getCid())){
                studentHasNotEvaluationCourses.remove(courseItem);
            }
        }

        student.setHasNotEvaluationCourses(studentHasNotEvaluationCourses);

        Set<Student> studentSet = evaluationCourse.getHasEvaluationStudents();
        studentSet.add(student);
        evaluationCourse.setHasEvaluationStudents(studentSet);
        evaluationCard.setStudent(student);
        evaluationCard.setCourse(evaluationCourse);
        Set<EvaluationCard> evaluationCourseCards = evaluationCourse.getEvaluationCards();
        evaluationCourseCards.add(evaluationCard);
        evaluationCourse.setEvaluationCards(evaluationCourseCards);

        if (evaluationCourse.getHasNotEvaluationStudents().size() == 0){
            evaluationCourse.setHasEvaluation(true);
        }
        studentDao.update(student);
        courseDao.update(evaluationCourse);

        return true;
    }
    @Transactional
    public void applyClassroom(Student student, String buildId, String buildNumber, Date startTime, Date endTime,  String reason, String classroomNumber,String applyPerson, String applyPersonPhone) throws Exception {
        if(endTime.getTime() <= startTime.getTime()|| endTime.getTime() < new Date().getTime()){
            throw new Exception("后置时间小于等于前置时间");
        }
//        检查是否时间 冲突
        ClassroomApplySheet classroomApplySheet = new ClassroomApplySheet();
        classroomApplySheet.setBuilding(buildingDao.getById(Integer.valueOf(buildId)));
        classroomApplySheet.setBuildingNumber(buildNumber);

        List<ClassroomApplySheet> classroomApplySheets = classroomApplySheetDao.getByObject(classroomApplySheet);
        for(ClassroomApplySheet classroomApplySheet1 : classroomApplySheets){
            if (classroomApplySheet1.getResult() == null || classroomApplySheet1.getResult().equals("通过")){
                if(classroomApplySheet1.getStartTime().getTime()>=endTime.getTime()){

                }else if (classroomApplySheet1.getEndTime().getTime()<=startTime.getTime()){

                }else {
                    throw new Exception("时间冲突");
                }
            }

        }

        classroomApplySheet.setStartTime(startTime);
        classroomApplySheet.setEndTime(endTime);
        classroomApplySheet.setStudentId(student.getSid());
        classroomApplySheet.setStudentName(student.getName());
        classroomApplySheet.setReason(reason);
        classroomApplySheet.setClassroomNumber(classroomNumber);
        classroomApplySheetDao.save(classroomApplySheet);
    }

        public List<Student> getStudentList() {
        return (List<Student>) studentDao.getHibernateTemplate().find("From Student");
    }

        public List<ClassroomApplySheet> getClassroomApplySheetList() {
        return (List<ClassroomApplySheet>) classroomApplySheetDao.getHibernateTemplate().find("From ClassroomApplySheet");
    }

        public List<DormExchangeSheet> getDormExchangeSheetList() {
        return (List<DormExchangeSheet>) dormExchangeSheetDao.getHibernateTemplate().find("From DormExchangeSheet");
    }

        public List<LogisticsRepairSheet> getLogisticsRepairSheetList() {
        return (List<LogisticsRepairSheet>) logisticsRepairSheetDao.getHibernateTemplate().find("From LogisticsRepairSheet");
    }
        public List<UploadFile> getUploadFileList() {
        return (List<UploadFile>) uploadFileDao.getHibernateTemplate().find("From UploadFile");
    }


        public ClassroomApplySheet getClassroomApplySheet(Integer id) {
        return  classroomApplySheetDao.getById(id);

    }

        public DormExchangeSheet getDormExchangeSheet(Integer id) {
        return  dormExchangeSheetDao.getById(id);

    }

        public LogisticsRepairSheet getLogisticsRepairSheet(Integer id) {
        return  logisticsRepairSheetDao.getById(id);

    }

        public UploadFile getUploadFile(Integer id) {
        return  uploadFileDao.getById(id);

    }

        public List<Student> findStudentList(String name) {
        Student student = new Student();
        student.setName(name);
        return (List<Student>) studentDao.getHibernateTemplate().findByExample(student);
    }
    @Transactional
    public void deleteStudentByID(Integer id) {
        Student student = studentDao.getById(id);
        studentDao.delete(student);
    }

    @Transactional
    public void updateStudentByID(Student student) {
        studentDao.update(student);
    }

    public void saveStudentList(Student student){
        studentDao.save(student);
    }

    public Student getStudentById(Integer id) {
        return studentDao.getById(id);
    }


}
