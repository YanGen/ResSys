package com.muhuan.service;

import com.muhuan.dao.SchoolFileDaoImpl;
import com.muhuan.dao.UploadFileDaoImpl;
import com.muhuan.model.util.SchoolFile;
import com.muhuan.model.util.UploadFile;
import com.muhuan.utils.General.FileExistJudgeUtil;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

/**
 * @author young
 * @ProjectName: ResSys
 * @Description: TODO()
 * @date 2018/12/9 19:52
 */
@Service
@Transactional
public class FileService {

    @Autowired
    private UploadFileDaoImpl uploadFileDao;
    @Autowired
    private SchoolFileDaoImpl schoolFileDao;


    public UploadFile getFileById(Integer id){
        return uploadFileDao.getById(id);
    }


    public String savaFile (File picture, UploadFile file, String realPath) throws Exception{
        //判断路径是否存在,不存在创建
        File dir = new File(realPath);
        FileExistJudgeUtil.judgeDirExists(dir);
        FileUtils.moveFile(picture,new File(dir,file.getNewName()));//剪切文件,推荐使用,无备份文件
        return String.valueOf(uploadFileDao.save(file));
    }

    public SchoolFile getSchoolFileById(Integer id){
        return schoolFileDao.getById(id);
    }

    public String savaSchoolFile (File picture, SchoolFile file, String realPath) throws Exception{
        //判断路径是否存在,不存在创建
        File dir = new File(realPath);
        FileExistJudgeUtil.judgeDirExists(dir);
        FileUtils.moveFile(picture,new File(dir,file.getNewName()));//剪切文件,推荐使用,无备份文件
        return String.valueOf(schoolFileDao.save(file));
    }
}
