package com.muhuan.service;

import com.muhuan.dao.BuildingDaoImpl;
import com.muhuan.model.school.Building;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author young
 * @ProjectName: ResSys
 * @Description: TODO()
 * @date 2018/12/7 9:50
 */
@Service("buildingService")
public class BuildingService {
    @Autowired
    private BuildingDaoImpl buildingDao;

    public Building getBuilding(Integer buildingId){
        return buildingDao.getById(buildingId);
    }

    public Map<String,Object> repairAreaAll() {
        List<Building> buildingList = buildingDao.getAll();
        Map<String,Object> dataMap = new HashMap<>();
        Map<String,Object> dormMap = new HashMap<>();
        Map<String,Object> pubAreaMap = new HashMap<>();

        for (Building building:buildingList){
            String buildString = "";
            for (int i = 1;i<=building.getNumber();i++){
                buildString += (building.getBuildingType().getName()+"-"+building.getId()+"-"+i+"|"+building.getName()+i+"号");
                if(i!=building.getNumber()){
                    buildString += ",";
                }
            }
            if (building.getBuildingType().getName().equals("学生宿舍")){
                dormMap.put(building.getBuildingType().getName(),buildString);
            }else if (building.getBuildingType().getName().equals("教师宿舍")){
                dormMap.put(building.getBuildingType().getName(),buildString);
            }else {
                pubAreaMap.put(building.getBuildingType().getName(),buildString);
            }

        }
        dataMap.put("宿舍区域",dormMap);
        dataMap.put("公共区域",pubAreaMap);

        System.out.println(dataMap);
        return dataMap;
    }



    public Map<String,Object> classroomAreaAll() {
        List<Building> buildingList = buildingDao.getAll();
        Map<String,Object> dataMap = new HashMap<>();
        Map<String,Object> areaMap = new HashMap<>();

        for (Building building:buildingList){
            String buildString = "";
            for (int i = 1;i<=building.getNumber();i++){
                buildString += (building.getBuildingType().getName()+"-"+building.getId()+"-"+i+"|"+building.getName()+i+"号");
                if(i!=building.getNumber()){
                    buildString += ",";
                }
            }
            if (building.getBuildingType().getName().equals("教室") || building.getBuildingType().getName().equals("实验室")){
                areaMap.put(building.getBuildingType().getName(),buildString);
            }

        }
//        dataMap.put("宿舍区域",dormMap);
        dataMap.put("教学区域",areaMap);

        System.out.println(dataMap);
        return dataMap;
    }
}
