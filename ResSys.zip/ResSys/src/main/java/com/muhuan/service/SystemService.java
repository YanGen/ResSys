package com.muhuan.service;

import com.muhuan.dao.StudentDaoImpl;
import com.muhuan.dao.TeacherDaoImpl;
import com.muhuan.model.basic.Device;
import com.muhuan.model.school.Student;
import com.muhuan.model.school.Teacher;
import org.hibernate.criterion.DetachedCriteria;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @author young
 * @ClassName: SystemService
 * @Description: TODO()
 * @date 2018/9/27 20:22
 */
@Service("systemService")
@Transactional

public class SystemService {

    @Autowired
    private StudentDaoImpl studentDao;
    @Autowired
    private TeacherDaoImpl teacherDao;


    /**
     * 验证登录
     * @param username
     * @param password
     * @param idtt 身份类型
     * @return
     */
    public Object userLoginCheck(String username,String password,String idtt){
        if(idtt.equals("t2")){
            Student student = new Student();
            student.setStudentCode(username);
            student.setPassword(password);
            return studentDao.getHibernateTemplate().findByExample(student);
        }else if (idtt.equals("t3")){
            Teacher teacher = new Teacher();
            teacher.setTeacherCode(username);
            teacher.setPassword(password);
            teacher.setTeacherIsAdmin(null);
            return teacherDao.getHibernateTemplate().findByExample(teacher);

        }else {
            return null;
        }
    }

    public boolean teacherIsAdmin(String username){
        return true;
    }


    public Student getStudentByStudentNumber(String  i) {
        return studentDao.getByStudentNumber(i);
    }

    public List<Teacher> getTeacherList() {
        return(List<Teacher>)teacherDao.getHibernateTemplate().find("Select id,name,unit From Teacher");
    }
}
