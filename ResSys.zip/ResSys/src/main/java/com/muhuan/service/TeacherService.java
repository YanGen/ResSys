package com.muhuan.service;

import com.muhuan.dao.*;
import com.muhuan.model.flow.ClassroomApplySheet;
import com.muhuan.model.flow.DeviceApplyReceiptSheet;
import com.muhuan.model.flow.DeviceApplySheet;
import com.muhuan.model.school.Teacher;
import com.muhuan.model.util.Pager;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @author young
 * @ClassName: TeacherService
 * @Description: TODO()
 * @date 2018/10/26 9:51
 */
@Service("teacherService")
@Transactional
public class TeacherService {
    @Autowired
    private TeacherDaoImpl teacherDao;
    @Autowired
    private DeviceApplySheetDaoImpl deviceApplySheetDao;
    @Autowired
    private ClassroomApplySheetDaoImpl classroomApplySheetDao;
    @Autowired
    private DeviceApplyReceiptSheetDaoImpl deviceApplyReceiptSheetDao;

    public List<DeviceApplySheet> getProveDeviceApplyList(String teachetCode, Pager<DeviceApplySheet> pager) {
        DetachedCriteria detachedCriteria = DetachedCriteria.forClass(DeviceApplySheet.class);
        detachedCriteria.setResultTransformer(DetachedCriteria.DISTINCT_ROOT_ENTITY);
        detachedCriteria.add(Restrictions.eq("teacherCode",teachetCode));
        detachedCriteria.add(Restrictions.eq("hasProve",false));
        return deviceApplySheetDao.getList(detachedCriteria,pager.getStart(),pager.getPageSize());

    }

    public void proveDeviceApply(Integer deviceId) {
        DeviceApplySheet deviceApplySheet = deviceApplySheetDao.getById(deviceId);
        deviceApplySheet.setHasProve(true);
        deviceApplySheetDao.update(deviceApplySheet);
    }

    public void disproveDeviceApply(Integer sheetId ,DeviceApplyReceiptSheet deviceApplyReceiptSheet) {
        deviceApplyReceiptSheet.setDeviceApplySheet(deviceApplySheetDao.getById(sheetId));
        deviceApplyReceiptSheet.setAllowNumber(0);
        deviceApplyReceiptSheetDao.save(deviceApplyReceiptSheet);
        deviceApplySheetDao.delete(sheetId);

    }

    public List<ClassroomApplySheet> getProveClassroomApplyList(String teacherCode, Pager<ClassroomApplySheet> sheetPager) {
        DetachedCriteria detachedCriteria = DetachedCriteria.forClass(ClassroomApplySheet.class);
        detachedCriteria.setResultTransformer(DetachedCriteria.DISTINCT_ROOT_ENTITY);
//        detachedCriteria.add(Restrictions.eq("teacherCode",teacherCode));
        detachedCriteria.add(Restrictions.eq("hasProve",false));

        return classroomApplySheetDao.getList(detachedCriteria,sheetPager.getStart(),sheetPager.getPageSize());
    }

    public void proveClassroomApply(Integer sheetId) {
        ClassroomApplySheet classroomApplySheet = classroomApplySheetDao.getById(sheetId);
        classroomApplySheet.setHasProve(true);
        classroomApplySheetDao.update(classroomApplySheet);
        return;
    }

    public void disproveClassroomApply(Integer sheetId, ClassroomApplySheet classroomApplySheet) {
    }

    public List<Teacher> getTeacherList() {
        return (List<Teacher>) teacherDao.getHibernateTemplate().find("From Teacher");
    }

    public List<Teacher> findTeacherList(String name) {
        Teacher teacher = new Teacher();
        teacher.setName(name);
        return (List<Teacher>) teacherDao.getHibernateTemplate().findByExample(teacher);
    }

    @Transactional
    public void deleteTeacherByID(Integer id) {
        Teacher teacher = teacherDao.getById(id);
        teacherDao.delete(teacher);
    }

    @Transactional
    public void updateTeacherByID(Teacher teacher) {
        teacherDao.update(teacher);
    }

    @Transactional
    public void saveTeacherList(Teacher teacher) {
        teacherDao.save(teacher);
    }

    public Teacher getTeacherById(Integer id) {
        return teacherDao.getById(id);
    }
}
