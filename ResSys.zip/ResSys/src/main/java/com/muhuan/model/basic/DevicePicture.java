package com.muhuan.model.basic;

import javax.persistence.*;

/**
 * Created by young on 2018/9/23.
 */
@Entity(name="DevicePicture")
@Table(name = "basic_device_picture")
public class DevicePicture implements java.io.Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    @Column(name = "id", nullable = false, length = 36)
    private Integer id;

    @Column(name = "name",nullable = false, length = 225)
    private String name;

    @Column(name = "link")
    private String link;

    @ManyToOne
    @JoinColumn(name="device_id")
    private Device device;

    public DevicePicture() {
    }

    public DevicePicture(Integer id, String name, String link, Device device) {
        this.id = id;
        this.name = name;
        this.link = link;
        this.device = device;
    }

    @Override
    public String toString() {
        return "DevicePicture{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", link='" + link + '\'' +
                ", device=" + device +
                '}';
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public Device getDevice() {
        return device;
    }

    public void setDevice(Device device) {
        this.device = device;
    }
}
