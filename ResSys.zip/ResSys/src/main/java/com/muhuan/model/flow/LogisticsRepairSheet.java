package com.muhuan.model.flow;

import com.muhuan.model.school.Building;
import com.muhuan.model.util.UploadFile;

import javax.persistence.*;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

@Entity(name = "LogisticsRepairSheet")
@Table(name = "flow_logistics_repair_sheet")
public class LogisticsRepairSheet {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id", nullable = false, length = 36)
    private Integer id;

    @OneToMany
    @JoinColumn(name="logistics_repair_sheet")
    private Set<UploadFile> pictures = new HashSet<>();

    @OneToOne
    @JoinColumn(name="building_id")
    private Building building;

    @Column(name = "building_detail")
    private String buildingDetail;

//    报修方向
    @Column(name = "repair_direction")
    private String repairDirection;
//    详情
    @Column(name = "repair_detail")
    private String repairDetaill;

    @Column(name = "what_day")
    private String whatDay;

    @Column(name = "what_time")
    private String whatTime;

    @Column(name = "repair_person")
    private String repairPerson;

    @Column(name = "person_phone")
    private String personPhone;

    @Column(name="user_info")
    private String userInfo;

    @Column(name = "apply_time")
    private Date applyTime;

    @Column(name = "status")
    private String status;

    @Column(name = "system_processing_time")
    private Date systemProcessingTime;

    @Column(name = "worker_processing_time")
    private Date workerProcessingTime;

    @Override
    public String toString() {
        return "LogisticsRepairSheet{" +
                "id=" + id +
                ", pictures=" + pictures +
                ", building=" + building +
                ", buildingDetail='" + buildingDetail + '\'' +
                ", repairDirection='" + repairDirection + '\'' +
                ", repairDetaill='" + repairDetaill + '\'' +
                ", whatDay='" + whatDay + '\'' +
                ", whatTime='" + whatTime + '\'' +
                ", repairPerson='" + repairPerson + '\'' +
                ", personPhone='" + personPhone + '\'' +
                ", userInfo='" + userInfo + '\'' +
                ", applyTime=" + applyTime +
                ", status='" + status + '\'' +
                ", systemProcessingTime=" + systemProcessingTime +
                ", workerProcessingTime=" + workerProcessingTime +
                '}';
    }


    public LogisticsRepairSheet() {
    }

    public LogisticsRepairSheet(Integer id, Set<UploadFile> pictures, Building building, String buildingDetail, String repairDirection, String repairDetaill, String whatDay, String whatTime, String repairPerson, String personPhone, String userInfo, Date applyTime, String status, Date systemProcessingTime, Date workerProcessingTime) {
        this.id = id;
        this.pictures = pictures;
        this.building = building;
        this.buildingDetail = buildingDetail;
        this.repairDirection = repairDirection;
        this.repairDetaill = repairDetaill;
        this.whatDay = whatDay;
        this.whatTime = whatTime;
        this.repairPerson = repairPerson;
        this.personPhone = personPhone;
        this.userInfo = userInfo;
        this.applyTime = applyTime;
        this.status = status;
        this.systemProcessingTime = systemProcessingTime;
        this.workerProcessingTime = workerProcessingTime;
    }

    public Date getApplyTime() {
        return applyTime;
    }

    public void setApplyTime(Date applyTime) {
        this.applyTime = applyTime;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getSystemProcessingTime() {
        return systemProcessingTime;
    }

    public void setSystemProcessingTime(Date systemProcessingTime) {
        this.systemProcessingTime = systemProcessingTime;
    }

    public Date getWorkerProcessingTime() {
        return workerProcessingTime;
    }

    public void setWorkerProcessingTime(Date workerProcessingTime) {
        this.workerProcessingTime = workerProcessingTime;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Set<UploadFile> getPictures() {
        return pictures;
    }

    public void setPictures(Set<UploadFile> pictures) {
        this.pictures = pictures;
    }

    public Building getBuilding() {
        return building;
    }

    public void setBuilding(Building building) {
        this.building = building;
    }

    public String getBuildingDetail() {
        return buildingDetail;
    }

    public void setBuildingDetail(String buildingDetail) {
        this.buildingDetail = buildingDetail;
    }

    public String getRepairDirection() {
        return repairDirection;
    }

    public void setRepairDirection(String repairDirection) {
        this.repairDirection = repairDirection;
    }

    public String getRepairDetaill() {
        return repairDetaill;
    }

    public void setRepairDetaill(String repairDetaill) {
        this.repairDetaill = repairDetaill;
    }

    public String getWhatDay() {
        return whatDay;
    }

    public void setWhatDay(String whatDay) {
        this.whatDay = whatDay;
    }

    public String getWhatTime() {
        return whatTime;
    }

    public void setWhatTime(String whatTime) {
        this.whatTime = whatTime;
    }

    public String getRepairPerson() {
        return repairPerson;
    }

    public void setRepairPerson(String repairPerson) {
        this.repairPerson = repairPerson;
    }

    public String getPersonPhone() {
        return personPhone;
    }

    public void setPersonPhone(String personPhone) {
        this.personPhone = personPhone;
    }

    public String getUserInfo() {
        return userInfo;
    }

    public void setUserInfo(String userInfo) {
        this.userInfo = userInfo;
    }
}
