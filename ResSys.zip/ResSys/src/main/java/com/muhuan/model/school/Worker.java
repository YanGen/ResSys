package com.muhuan.model.school;

import javax.persistence.*;

/**
 * Created by young on 2018/9/22.
 * 职工
 */
@Entity(name="Worker")
@Table(name = "school_worker")
public class Worker implements java.io.Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    @Column(name = "id", nullable = false, length = 36)
    private Integer id;
    @Column(name = "name", unique = true,nullable = false, length = 225)
    private String name;


    @ManyToOne(cascade=CascadeType.ALL,fetch=FetchType.EAGER)
    @JoinColumn(name="department_id")
    private Department department;

    @ManyToOne(cascade=CascadeType.ALL,fetch=FetchType.EAGER)
    @JoinColumn(name="major_id")
    private Department major;

    public Worker() {
    }

    public Worker(Integer id, String name, Department department, Department major) {
        this.id = id;
        this.name = name;
        this.department = department;
        this.major = major;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    public Department getMajor() {
        return major;
    }

    public void setMajor(Department major) {
        this.major = major;
    }
}
