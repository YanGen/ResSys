package com.muhuan.model.basic;

import javax.persistence.*;
import java.util.Set;

/**
 * Created by young on 2018/9/22.
 * 这个是设备
 */

@Entity(name="Device")
@Table(name = "basic_device")
public class Device implements java.io.Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id", nullable = false, length = 36)
    private Integer id;

    @Column(name = "name",nullable = false, length = 225)
    private String name;

    //数量
    @Column(name = "number", nullable = false)
    private Integer number =1;

    //设备类型
    @Column(name = "device_type")
    private String deviceType;

    //所有者
    @Column(name = "owner")
    private String owner;

//    位置
    private String location;

    @OneToMany(mappedBy = "device",cascade = CascadeType.ALL,fetch = FetchType.LAZY)
    private Set<DevicePicture> devicePictures;

    //余量
    @Column(name = "margin", nullable = false)
    private Integer margin=1;

    private String idesc;

    public Device() {
    }

    public Device(Integer id, String name, Integer number, String deviceType, String owner, String location, Set<DevicePicture> devicePictures, Integer margin) {
        this.id = id;
        this.name = name;
        this.number = number;
        this.deviceType = deviceType;
        this.owner = owner;
        this.location = location;
        this.devicePictures = devicePictures;
        this.margin = margin;
    }

    @Override
    public String toString() {
        return "Device{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", number=" + number +
                ", deviceType='" + deviceType + '\'' +
                ", owner='" + owner + '\'' +
                ", location='" + location + '\'' +
                ", devicePictures=" + devicePictures.toString() +
                ", margin=" + margin +
                '}';
    }

    public String getIdesc() {
        return idesc;
    }

    public void setIdesc(String idesc) {
        this.idesc = idesc;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getNumber() {
        return number;
    }

    public void setNumber(Integer number) {
        this.number = number;
    }

    public String getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(String deviceType) {
        this.deviceType = deviceType;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public Set<DevicePicture> getDevicePictures() {
        return devicePictures;
    }

    public void setDevicePictures(Set<DevicePicture> devicePictures) {
        this.devicePictures = devicePictures;
    }

    public Integer getMargin() {
        return margin;
    }

    public void setMargin(Integer margin) {
        this.margin = margin;
    }
}
