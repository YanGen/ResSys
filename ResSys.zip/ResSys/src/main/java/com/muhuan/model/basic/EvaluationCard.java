package com.muhuan.model.basic;

import com.muhuan.model.school.Student;
import com.muhuan.model.school.Teacher;

import javax.persistence.*;
import java.util.List;
import java.util.Set;

/**
 * @author young
 * @ClassName: EvaluationCard
 * @Description: TODO(评教卡)
 * @date 2018/11/10 15:53
 */
@Entity(name="EvaluationCard")
@Table(name = "basic_evaluation_card")
public class EvaluationCard implements java.io.Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    @Column(name = "id", nullable = false, length = 36)
    private Integer id;

    @OneToMany
    @JoinColumn(name = "evaluation_items")
    private List<EvaluationItem> evaluationItems;

    @OneToOne
    @JoinColumn(name = "course_id")
    private Course course;

    @OneToOne
    @JoinColumn(name="teacher_id")
    private Teacher teacher;

    @OneToOne
    @JoinColumn(name = "student_id")
    private Student student;

    @Column(name = "score_list")
    private String scoreList;


    @OneToOne
    @JoinColumn(name = "max_evaluation_item_id")
    private EvaluationItem maxEvaluationItem;

    @Column(name = "max_evaluation_item_score")
    private Integer maxEvaluationItemScore;

    @OneToOne
    @JoinColumn(name = "min_evaluation_item_id")
    private EvaluationItem minEvaluationItem;

    @Column(name = "min_evaluation_item_score")
    private Integer minEvaluationItemScore;

    public EvaluationCard() {
    }

    public EvaluationCard(Integer id, List<EvaluationItem> evaluationItems, Course course, Teacher teacher, Student student, String scoreList,  EvaluationItem maxEvaluationItem, Integer maxEvaluationItemScore, EvaluationItem minEvaluationItem, Integer minEvaluationItemScore) {
        this.id = id;
        this.evaluationItems = evaluationItems;
        this.course = course;
        this.teacher = teacher;
        this.student = student;
        this.scoreList = scoreList;
        this.maxEvaluationItem = maxEvaluationItem;
        this.maxEvaluationItemScore = maxEvaluationItemScore;
        this.minEvaluationItem = minEvaluationItem;
        this.minEvaluationItemScore = minEvaluationItemScore;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public List<EvaluationItem> getEvaluationItems() {
        return evaluationItems;
    }

    public void setEvaluationItems(List<EvaluationItem> evaluationItems) {
        this.evaluationItems = evaluationItems;
    }

    public Course getCourse() {
        return course;
    }

    public void setCourse(Course course) {
        this.course = course;
    }

    public Teacher getTeacher() {
        return teacher;
    }

    public void setTeacher(Teacher teacher) {
        this.teacher = teacher;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    public String getScoreList() {
        return scoreList;
    }

    public void setScoreList(String scoreList) {
        this.scoreList = scoreList;
    }

    public float getAverageScore() {

        String[] itemSore = this.getScoreList().split(",");

        float sum = 0;
        for(int i=0;i<itemSore.length;i++){
            sum += Double.parseDouble(itemSore[i]);
        }
        return sum / itemSore.length;
    }



    public EvaluationItem getMaxEvaluationItem() {
        return maxEvaluationItem;
    }

    public void setMaxEvaluationItem(EvaluationItem maxEvaluationItem) {
        this.maxEvaluationItem = maxEvaluationItem;
    }

    public Integer getMaxEvalueationItemScore() {
        return maxEvaluationItemScore;
    }

    public void setMaxEvalueationItemScore(Integer maxEvalueationItemScore) {
        this.maxEvaluationItemScore = maxEvalueationItemScore;
    }

    public EvaluationItem getMinEvaluationItem() {
        return minEvaluationItem;
    }

    public void setMinEvaluationItem(EvaluationItem minEvaluationItem) {
        this.minEvaluationItem = minEvaluationItem;
    }

    public Integer getMinEvaluationItemScore() {
        return minEvaluationItemScore;
    }

    public void setMinEvaluationItemScore(Integer minEvaluationItemScore) {
        this.minEvaluationItemScore = minEvaluationItemScore;
    }
}
