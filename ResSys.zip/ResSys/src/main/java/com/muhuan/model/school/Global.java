package com.muhuan.model.school;

import com.muhuan.model.util.SchoolFile;
import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity(name = "Global")
@Table(name = "global_settings")
public class Global {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id", nullable = false, length = 36)
    private Integer id;

    @OneToMany
    @JoinColumn(name="school_sheet")
    private Set<SchoolFile> pictures = new HashSet<>();

    @Column(name = "name")
    private String name;

    @Column(name = "ICP_num")
    private String icpnum;

    @Column(name = "web_detail")
    private String detail;

    @Column(name = "web_name")
    private String webname;

    @Column(name = "email")
    private String email;

    @Column(name = "telphone")
    private String telphone;




    public Global() {
    }

    public Global(Integer id, Set<SchoolFile> pictures, String name, String icpnum, String detail, String webname, String email, String telphone) {
        this.id = id;
        this.pictures = pictures;
        this.name = name;
        this.icpnum = icpnum;
        this.detail = detail;
        this.webname = webname;
        this.email = email;
        this.telphone = telphone;

    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Set<SchoolFile> getPictures() {
        return pictures;
    }

    public void setPictures(Set<SchoolFile> pictures) {
        this.pictures = pictures;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIcpnum() {
        return icpnum;
    }

    public void setIcpnum(String icpnum) {
        this.icpnum = icpnum;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    public String getWebname() {
        return webname;
    }

    public void setWebname(String webname) {
        this.webname = webname;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelphone() {
        return telphone;
    }

    public void setTelphone(String telphone) {
        this.telphone = telphone;
    }
}
