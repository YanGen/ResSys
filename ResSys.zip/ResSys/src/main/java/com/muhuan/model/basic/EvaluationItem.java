package com.muhuan.model.basic;

import javax.persistence.*;
import java.io.Serializable;

/**
 * @author young
 * @ClassName: EvaluationItem
 * @Description: TODO(评教项)
 * @date 2018/11/10 16:01
 */
@Entity(name="EvaluationItem")
@Table(name = "basic_evaluation_item")
public class EvaluationItem implements Serializable {
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    @Column(name = "id", nullable = false, length = 36)
    private Integer id;

    @Column(name = "item_name",unique = true)
    private String itemName;

    @Column(name = "score")
    private Integer score;

    public EvaluationItem() {
    }

    public EvaluationItem(Integer id, String itemName, Integer score) {
        this.id = id;
        this.itemName = itemName;
        this.score = score;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public Integer getScore() {
        return score;
    }

    public void setScore(Integer score) {
        this.score = score;
    }
}
