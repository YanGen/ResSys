package com.muhuan.model.flow;

import com.muhuan.model.basic.Device;

import javax.persistence.*;
import java.util.Date;

/**
 * Created by young on 2018/9/23.
 * 设备申请单
 */
@Entity(name = "DeviceApplySheet")
@Table(name = "flow_device_apply_sheet")
public class DeviceApplySheet implements java.io.Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id", nullable = false, length = 36)
    private Integer id;

    @Column(name = "studentId",nullable = false)
    private Integer studentId;

    @Column(name = "studentName",nullable = false,length = 225)
    private String studentName;
//  若此code为null则不经过老师证明，下面的hasProve作废
    @Column(name = "teacher_code")
    private String teacherCode = null;
//    即是否被证明，经老师同意后值为true
    @Column(name = "has_prove")
    private Boolean hasProve = false;
//    管理老师是否批准
    @Column(name = "admin_has_prove")
    private Boolean adminHasProve = false;

    @OneToOne
    @JoinColumn(name="device_id")
    private Device device;

    @Column(name = "applyNum",nullable = false,length = 225)
    private Integer applyNum = 1;

//    提交申请的日期,from系统
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "applyDate", length = 7)
    private Date applyDate = new Date();
//    归还日期，from用户
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "revertDate", length = 7)
    private Date revertDate;

    @Override
    public String toString() {
        return "DeviceApplySheet{" +
                "id=" + id +
                ", studentId=" + studentId +
                ", studentName='" + studentName + '\'' +
                ", teacherCode='" + teacherCode + '\'' +
                ", hasProve=" + hasProve +
                ", device=" + device.toString() +
                ", applyNum=" + applyNum +
                ", applyDate=" + applyDate +
                ", revertDate=" + revertDate +
                '}';
    }

    public DeviceApplySheet() {
    }

    public DeviceApplySheet(Integer id, Integer studentId, String studentName, String teacherCode, Boolean hasProve, Boolean adminHasProve, Device device, Integer applyNum, Date applyDate, Date revertDate) {
        this.id = id;
        this.studentId = studentId;
        this.studentName = studentName;
        this.teacherCode = teacherCode;
        this.hasProve = hasProve;
        this.adminHasProve = adminHasProve;
        this.device = device;
        this.applyNum = applyNum;
        this.applyDate = applyDate;
        this.revertDate = revertDate;
    }

    public Boolean getAdminHasProve() {
        return adminHasProve;
    }

    public void setAdminHasProve(Boolean adminHasProve) {
        this.adminHasProve = adminHasProve;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getStudentId() {
        return studentId;
    }

    public void setStudentId(Integer studentId) {
        this.studentId = studentId;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getTeacherCode() {
        return teacherCode;
    }

    public void setTeacherCode(String teacherCode) {
        this.teacherCode = teacherCode;
    }

    public Boolean getHasProve() {
        return hasProve;
    }

    public void setHasProve(Boolean hasProve) {
        this.hasProve = hasProve;
    }

    public Device getDevice() {
        return device;
    }

    public void setDevice(Device device) {
        this.device = device;
    }

    public Integer getApplyNum() {
        return applyNum;
    }

    public void setApplyNum(Integer applyNum) {
        this.applyNum = applyNum;
    }

    public Date getApplyDate() {
        return applyDate;
    }

    public void setApplyDate(Date applyDate) {
        this.applyDate = applyDate;
    }

    public Date getRevertDate() {
        return revertDate;
    }

    public void setRevertDate(Date revertDate) {
        this.revertDate = revertDate;
    }
}
