package com.muhuan.model.school;

import javax.persistence.*;
import java.util.Set;

/**
 * Created by young on 2018/9/23.
 * 映射老师的身份 普通？教务？办公室？
 */
@Entity(name="Identity")
@Table(name = "school_identity")
public class Identity implements java.io.Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    @Column(name = "id", nullable = false, length = 36)
    private Integer id;
    @Column(name = "name", unique = true,nullable = false, length = 225)
    private String name;
//    @OneToMany(mappedBy = "identity",cascade = CascadeType.ALL,fetch = FetchType.LAZY)
//    private Set<Student> students; //专业下的学生集合
    @OneToMany(mappedBy = "identity",cascade = CascadeType.ALL,fetch = FetchType.LAZY)
    private Set<Teacher> teachers;
//    @OneToMany(mappedBy = "identity",cascade = CascadeType.ALL,fetch = FetchType.LAZY)
//    private Set<Worker> workers;


    public Identity() {
    }

    public Identity(Integer id, String name, Set<Teacher> teachers) {
        this.id = id;
        this.name = name;
        this.teachers = teachers;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Set<Teacher> getTeachers() {
        return teachers;
    }

    public void setTeachers(Set<Teacher> teachers) {
        this.teachers = teachers;
    }
}
