package com.muhuan.model.basic;

import javax.persistence.*;

/**
 * @author young
 * @ProjectName: ResSys
 * @Description: TODO()
 * @date 2019/3/1 10:57
 */

@Entity(name="Sys_setting")
@Table(name="sys_setting")
public class Sys_setting implements java.io.Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    @Column(name = "id", nullable = false, length = 36)
    private Integer id;

    @Column(name = "web_name", unique = true,nullable = false, length = 225)
    private String web_name;

    @Column(name = "web_word", nullable = false)
    private String web_word;

    @Column(name = "web_mess", nullable = false)
    private String web_mess;

    @Column(name = "css_url", nullable = false)
    private String css_url;

    @Column(name = "admin_url", nullable = false)
    private String admin_url;

    @Column(name = "copyright", nullable = false)
    private String copyright;

    @Column(name = "web_num", nullable = false)
    private String web_num;

    @Column(name = "code", nullable = false)
    private String code;



    public Sys_setting(){
}

    public Sys_setting(Integer id, String web_name,String web_word,String web_mess,String css_url,String admin_url,String copyright,String web_num,String code) {
        this.id = id;
        this.web_name=web_name;
        this.web_word=web_word;
        this.web_mess=web_mess;
        this.css_url=css_url;
        this.admin_url=admin_url;
        this.copyright=copyright;
        this.web_num=web_num;
        this.code=code;

    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getWeb_name() {
        return web_name;
    }

    public void setWeb_name(String web_name) {
        this.web_name = web_name;
    }

    public String getWeb_word() {
        return web_word;
    }

    public void setWeb_word(String web_word) {
        this.web_word = web_word;
    }

    public String getWeb_mess() {
        return web_mess;
    }

    public void setWeb_mess(String web_mess) {
        this.web_mess = web_mess;
    }

    public String getCss_url() {
        return css_url;
    }

    public void setCss_url(String css_url) {
        this.css_url = css_url;
    }

    public String getAdmin_url() {
        return admin_url;
    }

    public void setAdmin_url(String admin_url) {
        this.admin_url = admin_url;
    }

    public String getCopyright() {
        return copyright;
    }

    public void setCopyright(String copyright) {
        this.copyright = copyright;
    }

    public String getWeb_num() {
        return web_num;
    }

    public void setWeb_num(String web_num) {
        this.web_num = web_num;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
}
