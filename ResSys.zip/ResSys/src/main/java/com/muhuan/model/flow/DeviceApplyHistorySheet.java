package com.muhuan.model.flow;

import javax.persistence.*;

/**
 * @author young
 * @ClassName: DeviceApplyHistorySheet
 * @Description: TODO(设备申请历史流水)
 * @date 2018/10/23 22:16
 */
@Entity(name = "DeviceApplyHistorySheet")
@Table(name = "flow_device_apply_history_sheet")
public class DeviceApplyHistorySheet {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id", nullable = false, length = 36)
    private Integer id;
    @OneToOne
    @JoinColumn(name="device_apply_sheet_id")
    private DeviceApplySheet deviceApplySheet;
    @OneToOne
    @JoinColumn(name = "device_apply_receipt_sheet_id")
    private DeviceApplyReceiptSheet deviceApplyReceiptSheet;
}
