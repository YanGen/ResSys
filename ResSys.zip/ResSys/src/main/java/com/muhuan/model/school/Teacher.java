package com.muhuan.model.school;

import javax.persistence.*;
import java.util.Set;

/**
 * Created by young on 2018/9/22.
 */
@Entity(name="Teacher")
@Table(name = "school_teacher")
public class Teacher implements java.io.Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    @Column(name = "id", nullable = false, length = 36)
    private Integer id;

    @Column(name = "name", unique = true,nullable = false, length = 225)
    private String name;

    @Column(name = "sex")
    private String sex;

    //年级也是入学年份
    @Column(name = "grade")
    private String grade;
    //unit班级避免命名冲突
    @Column(name = "unit")
    private String unit;

    @Column(name = "teacher_code")
    private String teacherCode;

    @Column(name = "password",nullable = false)
    private String password;

    @Column(name = "phone_number")
    private String phoneNumber;

    @Column(name = "teacher_is_admin")
    private Boolean teacherIsAdmin = false;

    @ManyToOne
    @JoinColumn(name="identity_id")
    private Identity identity;


    @ManyToOne
    @JoinColumn(name="major_id")
    private Major major;

    public Teacher() {
    }

    public Teacher(Integer id, String name, String sex, String grade, String unit, String teacherCode, String password, String phoneNumber, Boolean teacherIsAdmin, Identity identity, Major major) {
        this.id = id;
        this.name = name;
        this.sex = sex;
        this.grade = grade;
        this.unit = unit;
        this.teacherCode = teacherCode;
        this.password = password;
        this.phoneNumber = phoneNumber;
        this.teacherIsAdmin = teacherIsAdmin;
        this.identity = identity;
        this.major = major;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getTeacherCode() {
        return teacherCode;
    }

    public void setTeacherCode(String teacherCode) {
        this.teacherCode = teacherCode;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public Boolean getTeacherIsAdmin() {
        return teacherIsAdmin;
    }

    public void setTeacherIsAdmin(Boolean teacherIsAdmin) {
        this.teacherIsAdmin = teacherIsAdmin;
    }

    public Identity getIdentity() {
        return identity;
    }

    public void setIdentity(Identity identity) {
        this.identity = identity;
    }

    public Major getMajor() {
        return major;
    }

    public void setMajor(Major major) {
        this.major = major;
    }
}
