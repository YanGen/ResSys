package com.muhuan.model.flow;

import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * Created by young on 2018/9/23.
 * 宿舍的维修单
 */
@Entity(name = "DormRepairSheet")
@Table(name = "flow_dorm_repair_sheet")
public class DormRepairSheet implements java.io.Serializable {
    private static final long serialVersionUID = 1L;
}
