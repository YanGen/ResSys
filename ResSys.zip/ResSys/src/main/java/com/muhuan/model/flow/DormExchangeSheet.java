package com.muhuan.model.flow;

import com.muhuan.model.school.Building;
import com.muhuan.model.school.Student;

import javax.persistence.*;
import java.util.Date;

/**
 * Created by young on 2018/9/23.
 */
@Entity(name = "DormExchangeSheet")
@Table(name = "flow_dorm_exchange_sheet")
public class DormExchangeSheet implements java.io.Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id", nullable = false, length = 36)
    private Integer id;

    @Column(name = "old_dormitory")
    private String oldDormitory;

    @Column(name = "apply_time")
    private Date applyTime;

    @Column(name = "prove_time")
    private Date proveTime;

    @Column(name = "apply_result")
    private String applyResult = null;

    @OneToOne
    @JoinColumn(name = "new_building_id")
    private Building newBuilding;

    @Column(name = "new_building_number")
    private String newBuildingNumber;

    @Column(name = "new_building_room_number")
    private String newBuildingRoomNumber;

    @Column(name = "studentId",nullable = false)
    private Integer studentId;

    @Column(name = "studentName",nullable = false,length = 225)
    private String studentName;
    //  若此code为null则不经过老师证明，下面的hasProve作废
    @Column(name = "teacher_code")
    private String teacherCode = null;
    //    管理老师是否批准
    @Column(name = "admin_has_prove")
    private Boolean adminHasProve = false;

    public DormExchangeSheet() {
    }

    public DormExchangeSheet(Integer id, String oldDormitory, Date applyTime, Date proveTime, String applyResult, Building newBuilding, String newBuildingNumber, String newBuildingRoomNumber, Integer studentId, String studentName, String teacherCode, Boolean adminHasProve) {
        this.id = id;
        this.oldDormitory = oldDormitory;
        this.applyTime = applyTime;
        this.proveTime = proveTime;
        this.applyResult = applyResult;
        this.newBuilding = newBuilding;
        this.newBuildingNumber = newBuildingNumber;
        this.newBuildingRoomNumber = newBuildingRoomNumber;
        this.studentId = studentId;
        this.studentName = studentName;
        this.teacherCode = teacherCode;
        this.adminHasProve = adminHasProve;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getOldDormitory() {
        return oldDormitory;
    }

    public void setOldDormitory(String oldDormitory) {
        this.oldDormitory = oldDormitory;
    }

    public Date getApplyTime() {
        return applyTime;
    }

    public void setApplyTime(Date applyTime) {
        this.applyTime = applyTime;
    }

    public Date getProveTime() {
        return proveTime;
    }

    public void setProveTime(Date proveTime) {
        this.proveTime = proveTime;
    }

    public String getApplyResult() {
        return applyResult;
    }

    public void setApplyResult(String applyResult) {
        this.applyResult = applyResult;
    }

    public Building getNewBuilding() {
        return newBuilding;
    }

    public void setNewBuilding(Building newBuilding) {
        this.newBuilding = newBuilding;
    }

    public String getNewBuildingNumber() {
        return newBuildingNumber;
    }

    public void setNewBuildingNumber(String newBuildingNumber) {
        this.newBuildingNumber = newBuildingNumber;
    }

    public String getNewBuildingRoomNumber() {
        return newBuildingRoomNumber;
    }

    public void setNewBuildingRoomNumber(String newBuildingRoomNumber) {
        this.newBuildingRoomNumber = newBuildingRoomNumber;
    }

    public Integer getStudentId() {
        return studentId;
    }

    public void setStudentId(Integer studentId) {
        this.studentId = studentId;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getTeacherCode() {
        return teacherCode;
    }

    public void setTeacherCode(String teacherCode) {
        this.teacherCode = teacherCode;
    }

    public Boolean getAdminHasProve() {
        return adminHasProve;
    }

    public void setAdminHasProve(Boolean adminHasProve) {
        this.adminHasProve = adminHasProve;
    }
}
