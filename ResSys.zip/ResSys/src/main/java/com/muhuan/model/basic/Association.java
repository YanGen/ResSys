package com.muhuan.model.basic;

import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * Created by young on 2018/9/22.
 * 组织部门
 */
@Entity(name="Association")
@Table(name = "basic_association")
public class Association implements java.io.Serializable {
    private static final long serialVersionUID = 1L;
}
