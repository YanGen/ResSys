package com.muhuan.model.flow;

import com.muhuan.model.basic.Device;
import com.muhuan.model.school.Building;

import javax.persistence.*;
import java.util.Date;

/**
 * Created by young on 2018/9/23.
 * 课室申请表
 */
@Entity(name = "ClassroomApplySheet")
@Table(name = "flow_classroom_apply_sheet")
public class ClassroomApplySheet implements java.io.Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id", nullable = false, length = 36)
    private Integer id;

    @Column(name = "student_id",nullable = false)
    private Integer studentId;

    @Column(name = "student_name",nullable = false,length = 225)
    private String studentName;
    //  若此code为null则不经过老师证明，下面的hasProve作废
    @Column(name = "teacher_code")
    private String teacherCode = null;
    //    即是否被证明，经老师同意后值为true
    @Column(name = "has_prove")
    private Boolean hasProve = false;
    //    管理老师是否批准
    @Column(name = "admin_has_prove")
    private Boolean adminHasProve = false;

    @OneToOne
    @JoinColumn(name="building_id")
    private Building building;

    @Column(name = "building_number")
    private String buildingNumber;

    @Column(name = "classroom_number")
    private String classroomNumber;

    @Column(name = "reason")
    private String reason;

    //    提交申请的日期,from系统
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "start_time", length = 7)
    private Date startTime;
    //    归还日期，from用户
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "end_time", length = 7)
    private Date endTime;

    @Column(name = "apply_person")
    private String applyPerson;

    @Column(name = "apply_person_phone")
    private String applyPersonPhone;

    @Column(name = "illustrate")
    private String illustrate;

    @Column(name = "result")
    private String result;

    @Column(name = "teacher_name")
    private String teacherName;

    @Column(name = "teacher_id")
    private String teacherId;

    public ClassroomApplySheet() {
    }

    public ClassroomApplySheet(Integer id, Integer studentId, String studentName, String teacherCode, Boolean hasProve, Boolean adminHasProve, Building building, String buildingNumber, String classroomNumber, String reason, Date startTime, Date endTime, String applyPerson, String applyPersonPhone, String illustrate, String result, String teacherName, String teacherId) {
        this.id = id;
        this.studentId = studentId;
        this.studentName = studentName;
        this.teacherCode = teacherCode;
        this.hasProve = hasProve;
        this.adminHasProve = adminHasProve;
        this.building = building;
        this.buildingNumber = buildingNumber;
        this.classroomNumber = classroomNumber;
        this.reason = reason;
        this.startTime = startTime;
        this.endTime = endTime;
        this.applyPerson = applyPerson;
        this.applyPersonPhone = applyPersonPhone;
        this.illustrate = illustrate;
        this.result = result;
        this.teacherName = teacherName;
        this.teacherId = teacherId;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getStudentId() {
        return studentId;
    }

    public void setStudentId(Integer studentId) {
        this.studentId = studentId;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getTeacherCode() {
        return teacherCode;
    }

    public void setTeacherCode(String teacherCode) {
        this.teacherCode = teacherCode;
    }

    public Boolean getHasProve() {
        return hasProve;
    }

    public void setHasProve(Boolean hasProve) {
        this.hasProve = hasProve;
    }

    public Boolean getAdminHasProve() {
        return adminHasProve;
    }

    public void setAdminHasProve(Boolean adminHasProve) {
        this.adminHasProve = adminHasProve;
    }

    public Building getBuilding() {
        return building;
    }

    public void setBuilding(Building building) {
        this.building = building;
    }

    public String getBuildingNumber() {
        return buildingNumber;
    }

    public void setBuildingNumber(String buildingNumber) {
        this.buildingNumber = buildingNumber;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public String getClassroomNumber() {
        return classroomNumber;
    }

    public void setClassroomNumber(String classroomNumber) {
        this.classroomNumber = classroomNumber;
    }

    public String getApplyPerson() {
        return applyPerson;
    }

    public void setApplyPerson(String applyPerson) {
        this.applyPerson = applyPerson;
    }

    public String getApplyPersonPhone() {
        return applyPersonPhone;
    }

    public void setApplyPersonPhone(String applyPersonPhone) {
        this.applyPersonPhone = applyPersonPhone;
    }

    public String getIllustrate() {
        return illustrate;
    }

    public void setIllustrate(String illustrate) {
        this.illustrate = illustrate;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getTeacherName() {
        return teacherName;
    }

    public void setTeacherName(String teacherName) {
        this.teacherName = teacherName;
    }

    public String getTeacherId() {
        return teacherId;
    }

    public void setTeacherId(String teacherId) {
        this.teacherId = teacherId;
    }
}
