package com.muhuan.model.school;

import javax.persistence.*;

/**
 * @author young
 * @ProjectName: ResSys
 * @Description: TODO(学校的建筑)
 * @date 2018/11/16 17:15
 */
@Entity(name="Building")
@Table(name = "school_building")
public class Building {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy= GenerationType.AUTO)
    @Column(name = "id", nullable = false, length = 36)
    private Integer id;

    @Column(name = "name",nullable = false)
    private String name;

    //总数 ---- 将生成1 - number的楼宇号
    @Column(name = "number")
    private Integer number = 1;

//    这个楼是给谁用的，只接受student,teacher,worker
    @Column(name = "target" ,nullable = false)
    private String target;

    @OneToOne
    @JoinColumn(name = "building_type")
    private BuildingType buildingType;

    public Building() {
    }

    public Building(Integer id, String name, Integer number, String target, BuildingType buildingType) {
        this.id = id;
        this.name = name;
        this.number = number;
        this.target = target;
        this.buildingType = buildingType;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getNumber() {
        return number;
    }

    public void setNumber(Integer number) {
        this.number = number;
    }

    public String getTarget() {
        return target;
    }

    public void setTarget(String target) {
        this.target = target;
    }

    public BuildingType getBuildingType() {
        return buildingType;
    }

    public void setBuildingType(BuildingType buildingType) {
        this.buildingType = buildingType;
    }
}
