package com.muhuan.model.basic;

import javax.persistence.*;

/**
 * @author young
 * @ProjectName: ResSys
 * @Description: TODO()
 * @date 2019/3/1 10:57
 */

@Entity(name="Assn")
@Table(name="basic_assn")
public class Assn implements java.io.Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    @Column(name = "id", nullable = false, length = 36)
    private Integer id;

    @Column(name = "name", unique = true,nullable = false, length = 225)
    private String name;

    //简介
    @Column(name = "mess", nullable = false)
    private String mess;

    @Column(name = "image", nullable = false)
    private String image;


    public Assn(){
}

    public Assn(Integer id, String name,String mess,String image) {
        this.id = id;
        this.name = name;
        this.mess=mess;
        this.image = image;

    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMess() {return mess;}

    public void setMess(String mess) {this.mess=mess;}

    public String getImage()  {return image;}

    public void setImage(String image) {this.image=image;}
}
