package com.muhuan.model.school;

import com.muhuan.model.basic.Course;
import com.muhuan.model.basic.Dormitory;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by young on 2018/9/22.
 */
@Entity(name="Student")
@Table(name = "school_student")
public class Student implements java.io.Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    @Column(name = "sid", nullable = false, length = 36)
    private Integer sid;

    @Column(name = "name")
    private String name;

    @Column(name = "sex")
    private String sex;

    //年级也是入学年份
    @Column(name = "grade")
    private String grade;
    //unit班级避免命名冲突
    @Column(name = "unit")
    private String unit;

    @Column(name = "student_code")
    private String studentCode;

    @Column(name = "password",nullable = false)
    private String password;

    @ManyToOne
    @JoinColumn(name="major_id")
    private Major major;

    @ManyToMany(cascade = CascadeType.ALL)
    @JoinTable(name = "basic_student_map_course",joinColumns = @JoinColumn(name = "sid"),inverseJoinColumns = @JoinColumn(name = "cid"))
    private Set<Course> courses = new HashSet<>();

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "basic_student_map_has_not_evaluation_courses",joinColumns = @JoinColumn(name = "sid"),inverseJoinColumns = @JoinColumn(name = "cid"))
    private Set<Course> hasNotEvaluationCourses;

    @ManyToOne(fetch = FetchType.EAGER,cascade={CascadeType.ALL})
    @JoinColumn(name="dormitory_id",referencedColumnName="id")
    private Dormitory dormitory;

    public Student() {
    }

    public Student(Integer sid, String name, String sex, String grade, String unit, String studentCode, String password, Major major, Set<Course> courses, Set<Course> hasNotEvaluationCourses, Dormitory dormitory) {
        this.sid = sid;
        this.name = name;
        this.sex = sex;
        this.grade = grade;
        this.unit = unit;
        this.studentCode = studentCode;
        this.password = password;
        this.major = major;
        this.courses = courses;
        this.hasNotEvaluationCourses = hasNotEvaluationCourses;
        this.dormitory = dormitory;
    }

    public Integer getSid() {
        return sid;
    }

    public void setSid(Integer sid) {
        this.sid = sid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getStudentCode() {
        return studentCode;
    }

    public void setStudentCode(String studentCode) {
        this.studentCode = studentCode;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Major getMajor() {
        return major;
    }

    public void setMajor(Major major) {
        this.major = major;
    }

    public Set<Course> getCourses() {
        return courses;
    }

    public void setCourses(Set<Course> courses) {
        this.courses = courses;
    }

    public Set<Course> getHasNotEvaluationCourses() {
        return hasNotEvaluationCourses;
    }

    public void setHasNotEvaluationCourses(Set<Course> hasNotEvaluationCourses) {
        this.hasNotEvaluationCourses = hasNotEvaluationCourses;
    }

    public Dormitory getDormitory() {
        return dormitory;
    }

    public void setDormitory(Dormitory dormitory) {
        this.dormitory = dormitory;
    }
}
