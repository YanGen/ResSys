package com.muhuan.model.basic;

import javax.persistence.*;

/**
 * Created by young on 2018/9/22.
 */

@Entity(name="Classroom")
@Table(name = "basic_classroom")
public class Classroom implements java.io.Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    @Column(name = "id", nullable = false, length = 36)
    private Integer id;

    @Column(name = "name", unique = true,nullable = false, length = 225)
    private String name;

    //容量
    @Column(name = "capacity", nullable = false)
    private Integer capacity;

    //课室类型
    @Column(name = "room_type")
    private String roomType;

    //使用状态 -- 正在使用为true,反之
    @Column(name = "status", nullable = false)
    private Boolean status = false;

}
