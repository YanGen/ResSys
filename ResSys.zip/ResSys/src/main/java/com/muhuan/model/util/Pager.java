package com.muhuan.model.util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Created by young on 2018/9/24.
 */
public class Pager<T> {
    private static int DEFAULT_PAGE_SIZED=10;

    private int start;  //开始位置
    private int pageSize=DEFAULT_PAGE_SIZED;//一页显示的个数
    private int totalCount;//总记录数

    private List<Integer> middlePage;//当前页存放的记录

    public Pager(){
        this(0,0,DEFAULT_PAGE_SIZED,new ArrayList<Integer>());
    }

    public Pager(int start, int pageSize, int totalCount, List<Integer> middlePage) {
        this.start = start;
        this.pageSize = pageSize;
        this.totalCount = totalCount;
        this.middlePage = middlePage;
    }

    /**
     * 取总页数
     */
    public int getTotalPageCount(){
        if(totalCount%pageSize==0)
            return totalCount/pageSize;
        else
            return totalCount/pageSize+1;
    }

    /**
     *获取当前页
     */
    public int getCurrentPageNo(){
        return start/pageSize+1;
    }

    /**
     *是否有下一页
     */
    public boolean hasNextPage(){
        return this.getCurrentPageNo()<this.getTotalPageCount();
    }

    /**
     *是否有上一页
     */
    public boolean hasPreviousPage(){
        return this.getCurrentPageNo()>1;
    }

    public int getLast(){
        int last;
        // 假设总数是50，是能够被5整除的，那么最后一页的开始就是45
        if (0 == totalCount % pageSize)
            last = (totalCount - pageSize)/10;
            // 假设总数是51，不能够被5整除的，那么最后一页的开始就是50
        else
            last = (totalCount - totalCount % pageSize)/10;
        last = last<0?0:last;
        return last+1;
    }

    /**
     *
     * @param pageNo    页数
     * @param pageSize  一页显示记录数
     * @return           该页第一条数据位置
     */
    public static int getStartOfPage(int pageNo,int pageSize){
        return (pageNo-1)*pageSize;
    }

    /**
     * 任意一页第一条数据在数据集的位置
     */
    protected  static int getStartOfPage(int pageNo){
        return getStartOfPage(pageNo,DEFAULT_PAGE_SIZED);
    }

    public int getStart() {
        return start;
    }

    public void setStart(int start) {
        this.start = start;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public long getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(int totalCount) {
        this.totalCount = totalCount;
    }

    public List<Integer> getMiddlePage() {
        Integer currentPageNo = this.getCurrentPageNo();
        Integer totalPageCount = this.getTotalPageCount();
//        左右两侧页数
        int sideSize = 4;
//        左侧
        for(int i = 1;sideSize>=i;i++){
            if (currentPageNo-i==0){
                break;
            }
            middlePage.add(currentPageNo-i);
        }
        Collections.reverse(middlePage);
        middlePage.add(currentPageNo);
//        右侧
        for(int i = 1;sideSize>=i;i++){
            if (currentPageNo +i > totalPageCount){
                break;
            }
            middlePage.add(currentPageNo + i);
        }
        return middlePage;
    }

    public void setMiddlePage(List<Integer> middlePage) {
        this.middlePage = middlePage;
    }
}
