package com.muhuan.model.system;

import javax.persistence.*;

/**
 * Created by young on 2018/9/22.
 */

@Entity(name="School")
@Table(name = "system_school")

public class School implements java.io.Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    @Column(name = "id", nullable = false, length = 36)
    private Integer id;
    @Column(name = "name", nullable = false, length = 225)
    private String name;
    @Column(name = "eng_name", nullable = false, length = 225)
    private String engName;
    @Column(name = "icon", nullable = false, length = 225)
    private String icon;
    @Column(name = "website", nullable = false, length = 225)
    private String website;
    @Column(name = "address", nullable = false, length = 225)
    private String address;

    public School() {
    }

    public School(Integer id, String name, String engName, String icon, String website, String address) {
        this.id = id;
        this.name = name;
        this.engName = engName;
        this.icon = icon;
        this.website = website;
        this.address = address;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEngName() {
        return engName;
    }

    public void setEngName(String engName) {
        this.engName = engName;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public String getWebsite() {
        return website;
    }

    public void setWebsite(String website) {
        this.website = website;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
