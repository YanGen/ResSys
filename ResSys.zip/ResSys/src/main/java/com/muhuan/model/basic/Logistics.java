package com.muhuan.model.basic;

import javax.persistence.Entity;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * Created by young on 2018/9/23.
 * 后勤单位
 */
@Entity(name="Logistics")
@Table(name = "basic_logistics")
public class Logistics implements java.io.Serializable {
    private static final long serialVersionUID = 1L;
}
