package com.muhuan.model.school;

import javax.persistence.*;
import java.util.Set;

/**
 * Created by young on 2018/9/22.
 * 专业
 */
@Entity(name="Major")
@Table(name = "school_major")
public class Major implements java.io.Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    @Column(name = "id", nullable = false, length = 36)
    private Integer id;
    //编号
    @Column(name = "code",nullable = true)
    private String code;

    @Column(name = "name", unique = true,nullable = false, length = 225)
    private String name;

    @ManyToOne
    @JoinColumn(name="department_id")
    @Basic(fetch=FetchType.LAZY)
    private Department department;

    @OneToMany(mappedBy = "major",cascade = CascadeType.ALL)
    private Set<Student> students; //专业下的学生集合
    @OneToMany(mappedBy = "major",cascade = CascadeType.ALL)
    private Set<Teacher> teachers;
    @OneToMany(mappedBy = "major",cascade = CascadeType.ALL)
    private Set<Worker> workers;

    @Override
    public String toString() {
        return "Major{" +
                "id=" + id +
                ", code='" + code + '\'' +
                ", name='" + name + '\'' +
                ", department=" + department +
                ", students=" + students +
                ", teachers=" + teachers +
                ", workers=" + workers +
                '}';
    }

    public Major() {
    }

    public Major(Integer id, String code, String name, Department department, Set<Student> students, Set<Teacher> teachers, Set<Worker> workers) {
        this.id = id;
        this.code = code;
        this.name = name;
        this.department = department;
        this.students = students;
        this.teachers = teachers;
        this.workers = workers;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    public Set<Student> getStudents() {
        return students;
    }

    public void setStudents(Set<Student> students) {
        this.students = students;
    }

    public Set<Teacher> getTeachers() {
        return teachers;
    }

    public void setTeachers(Set<Teacher> teachers) {
        this.teachers = teachers;
    }

    public Set<Worker> getWorkers() {
        return workers;
    }

    public void setWorkers(Set<Worker> workers) {
        this.workers = workers;
    }
}
