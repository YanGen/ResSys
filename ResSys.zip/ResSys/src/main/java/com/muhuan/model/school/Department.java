package com.muhuan.model.school;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * Created by young on 2018/9/22.
 * 院系
 */
@Entity(name="Department")
@Table(name = "school_department")
public class Department implements java.io.Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    @Column(name = "id", nullable = false, length = 36)
    private Integer id;
    //编号
    @Column(name = "code")
    private String code;

    @Column(name = "name", unique = true,nullable = false, length = 225)
    private String name;

    @OneToMany(mappedBy="department",cascade={CascadeType.ALL})
    private Set<Major> majors; //部门下的专业集合

    @Override
    public String toString() {
        return "Department{" +
                "id=" + id +
                ", code='" + code + '\'' +
                ", name='" + name + '\'' +
                ", majors=" + majors +
                '}';
    }

    public Department() {
    }

    public Department(Integer id, String code, String name, Set<Major> majors) {
        this.id = id;
        this.code = code;
        this.name = name;
        this.majors = majors;

    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


}
