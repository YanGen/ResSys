package com.muhuan.model.util;

import javax.persistence.*;
import java.util.Date;

/**
 * @author young
 * @ProjectName: ResSys
 * @Description: TODO()
 * @date 2018/12/9 19:23
 */
@Entity(name="UploadFile")
@Table(name = "util_upload_file")
public class UploadFile {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id", nullable = false, length = 36)
    private Integer id;

    @Column(name = "from_user")
    private String fromUser;

    @Column(name = "post_ip")
    private String postIp;

    @Column(name = "post_ua")
    private String postUA;

    @Column(name = "post_date")
    private Date postDate;

    @Column(name = "type")
    private String fileContentType;

    @Column(name = "suffix")
    private String suffix;

    @Column(name = "old_name")
    private String oldName;

    @Column(name = "new_name")
    private String newName;

    @Column(name = "path")
    private String path = "/";

    public UploadFile() {
    }

    public UploadFile(Integer id, String fromUser, String postIp, String postUA, Date postDate, String fileContentType, String suffix, String oldName, String newName, String path) {
        this.id = id;
        this.fromUser = fromUser;
        this.postIp = postIp;
        this.postUA = postUA;
        this.postDate = postDate;
        this.fileContentType = fileContentType;
        this.suffix = suffix;
        this.oldName = oldName;
        this.newName = newName;
        this.path = path;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getOldName() {
        return oldName;
    }

    public void setOldName(String oldName) {
        this.oldName = oldName;
    }

    public String getNewName() {
        return newName;
    }

    public void setNewName(String newName) {
        this.newName = newName;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getFromUser() {
        return fromUser;
    }

    public void setFromUser(String fromUser) {
        this.fromUser = fromUser;
    }

    public String getPostIp() {
        return postIp;
    }

    public void setPostIp(String postIp) {
        this.postIp = postIp;
    }

    public String getPostUA() {
        return postUA;
    }

    public void setPostUA(String postUA) {
        this.postUA = postUA;
    }

    public Date getPostDate() {
        return postDate;
    }

    public void setPostDate(Date postDate) {
        this.postDate = postDate;
    }

    public String getSuffix() {
        return suffix;
    }

    public void setSuffix(String suffix) {
        this.suffix = suffix;
    }

    public String getFileContentType() {
        return fileContentType;
    }

    public void setFileContentType(String fileContentType) {
        this.fileContentType = fileContentType;
    }
}
