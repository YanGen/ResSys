package com.muhuan.model.basic;

import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * Created by young on 2018/9/23.
 */
@Entity(name = "Place")
@Table(name = "basic_place")
public class Place implements java.io.Serializable {
    private static final long serialVersionUID = 1L;
}
