package com.muhuan.model.flow;

import javax.persistence.*;
import java.util.Date;

/**
 * @author young
 * @ClassName: DeviceApplyReceiptSheet
 * @Description: TODO(设备申请回执)
 * @date 2018/10/23 22:15
 */
@Entity(name = "DeviceApplyReceiptSheet")
@Table(name = "flow_device_apply_receipt_sheet")
public class DeviceApplyReceiptSheet {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id", nullable = false, length = 36)
    private Integer id;

    @Column(name = "teacher_id",nullable = false)
    private Integer teacherId;

    @Column(name = "teacher_name",nullable = false)
    private String teacherName;

    // 批准 ， 修改 ，不批准
    @Column(name = "result",nullable = false )
    private String result;
    //若是修改，则采用allowNumber
    @Column(name = "allow_number",nullable = true)
    private Integer allowNumber;
    // 审核说明
    @Column(name = "illustrate")
    private String illustrate;
    // 若批准，则生成凭证
    @Column(name = "voucher")
    private String voucher;
    // 凭证对应的有效期
    @Column(name="voucher_date")
    private Date voucherDate;
    // 管理处理日期
    @Column(name = "process_date")
    private Date processDate = new Date();

    @OneToOne
    @JoinColumn(name="device_apply_sheet_id")
    private DeviceApplySheet deviceApplySheet;

    public DeviceApplyReceiptSheet() {
    }


    public DeviceApplyReceiptSheet(Integer id, Integer teacherId, String teacherName, String result, Integer allowNumber, String illustrate, String voucher, Date voucherDate, Date processDate, DeviceApplySheet deviceApplySheet) {
        this.id = id;
        this.teacherId = teacherId;
        this.teacherName = teacherName;
        this.result = result;
        this.allowNumber = allowNumber;
        this.illustrate = illustrate;
        this.voucher = voucher;
        this.voucherDate = voucherDate;
        this.processDate = processDate;
        this.deviceApplySheet = deviceApplySheet;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getTeacherId() {
        return teacherId;
    }

    public void setTeacherId(Integer teacherId) {
        this.teacherId = teacherId;
    }

    public String getTeacherName() {
        return teacherName;
    }

    public void setTeacherName(String teacherName) {
        this.teacherName = teacherName;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public Integer getAllowNumber() {
        return allowNumber;
    }

    public void setAllowNumber(Integer allowNumber) {
        this.allowNumber = allowNumber;
    }

    public String getIllustrate() {
        return illustrate;
    }

    public void setIllustrate(String illustrate) {
        this.illustrate = illustrate;
    }

    public String getVoucher() {
        return voucher;
    }

    public void setVoucher(String voucher) {
        this.voucher = voucher;
    }

    public Date getVoucherDate() {
        return voucherDate;
    }

    public void setVoucherDate(Date voucherDate) {
        this.voucherDate = voucherDate;
    }

    public Date getProcessDate() {
        return processDate;
    }

    public void setProcessDate(Date processDate) {
        this.processDate = processDate;
    }

    public DeviceApplySheet getDeviceApplySheet() {
        return deviceApplySheet;
    }

    public void setDeviceApplySheet(DeviceApplySheet deviceApplySheet) {
        this.deviceApplySheet = deviceApplySheet;
    }
}
