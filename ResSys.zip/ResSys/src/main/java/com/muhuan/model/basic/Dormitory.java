package com.muhuan.model.basic;

import com.muhuan.model.school.Building;
import com.muhuan.model.school.Student;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by young on 2018/9/22.
 * 宿舍
 */
@Entity(name="Dormitory")
@Table(name = "basic_dormitory")
public class Dormitory implements java.io.Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    @Column(name = "id", nullable = false, length = 36)
    private Integer id;

    @OneToOne
    @JoinColumn(name="building_id")
    private Building building;

    @Column(name = "building_number")
    private String buildingNumber;

    @Column(name = "room_number")
    private String roomNumber;

    @OneToMany(fetch = FetchType.EAGER ,  cascade = { CascadeType.ALL },mappedBy = "dormitory")
    private List<Student> students = new ArrayList<>();

    public Dormitory() {
    }

    public Dormitory(Integer id, Building building, String buildingNumber, String roomNumber, List<Student> students) {
        this.id = id;
        this.building = building;
        this.buildingNumber = buildingNumber;
        this.roomNumber = roomNumber;
        this.students = students;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Building getBuilding() {
        return building;
    }

    public void setBuilding(Building building) {
        this.building = building;
    }

    public String getBuildingNumber() {
        return buildingNumber;
    }

    public void setBuildingNumber(String buildingNumber) {
        this.buildingNumber = buildingNumber;
    }

    public String getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }

    public List<Student> getStudents() {
        return students;
    }

    public void setStudents(List<Student> students) {
        this.students = students;
    }
}
