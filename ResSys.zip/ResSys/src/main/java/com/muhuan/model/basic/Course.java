package com.muhuan.model.basic;

import com.muhuan.model.school.Student;
import com.muhuan.model.school.Teacher;

import javax.persistence.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

/**
 * @author young
 * @ClassName: Course
 * @Description: TODO(课程)
 * @date 2018/11/10 16:31
 */
@Entity(name="Course")
@Table(name = "basic_course")
public class Course implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    @Column(name = "cid", nullable = false, length = 36)
    private Integer cid;

    @OneToOne
    @JoinColumn(name="teacher_id")
    private Teacher teacher;

    @Column(name = "start_evaluation")
    private Boolean startEvaluation = false;

    @Column(name = "has_evaluation")
    private Boolean hasEvaluation = false;

    @ManyToMany(mappedBy = "courses",cascade=CascadeType.ALL)
    private Set<Student> students;

    @OneToMany
    @JoinColumn(name = "has_evaluation_courses")
    private Set<Student> hasEvaluationStudents = new HashSet<>();

    @ManyToMany(mappedBy = "hasNotEvaluationCourses")
    private Set<Student> hasNotEvaluationStudents = new HashSet<>();

    @OneToMany(cascade= {CascadeType.ALL},fetch=FetchType.LAZY)
    @JoinColumn(name="course_id")
    private Set<EvaluationCard> evaluationCards;

    @Column(name = "class_place")
    private String classPlace;

    @Column(name = "course_name")
    private String courseName;

//    备注信息
    @Column(name = "course_info")
    private String courseInfo;


    @Override
    public String toString() {
        return "Course{" +
                "cid=" + cid +
                ", teacher=" + teacher +
                ", startEvaluation=" + startEvaluation +
                ", classPlace='" + classPlace + '\'' +
                ", courseName='" + courseName + '\'' +
                ", courseInfo='" + courseInfo + '\'' +
                '}';
    }

    public Course() {
    }

    public Course(Integer cid, Teacher teacher, Boolean startEvaluation, Boolean hasEvaluation, Set<Student> students, Set<Student> hasEvaluationStudents, Set<EvaluationCard> evaluationCards, String classPlace, String courseName, String courseInfo) {
        this.cid = cid;
        this.teacher = teacher;
        this.startEvaluation = startEvaluation;
        this.hasEvaluation = hasEvaluation;
        this.students = students;
        this.hasEvaluationStudents = hasEvaluationStudents;
        this.evaluationCards = evaluationCards;
        this.classPlace = classPlace;
        this.courseName = courseName;
        this.courseInfo = courseInfo;
    }

    public Set<Student> getHasNotEvaluationStudents() {
        return hasNotEvaluationStudents;
    }

    public void setHasNotEvaluationStudents(Set<Student> hasNotEvaluationStudents) {
        this.hasNotEvaluationStudents = hasNotEvaluationStudents;
    }

    public Integer getCid() {
        return cid;
    }

    public void setCid(Integer cid) {
        this.cid = cid;
    }

    public Teacher getTeacher() {
        return teacher;
    }

    public void setTeacher(Teacher teacher) {
        this.teacher = teacher;
    }

    public Boolean getStartEvaluation() {
        return startEvaluation;
    }

    public void setStartEvaluation(Boolean startEvaluation) {
        this.startEvaluation = startEvaluation;
    }

    public Boolean getHasEvaluation() {
        return hasEvaluation;
    }

    public void setHasEvaluation(Boolean hasEvaluation) {
        this.hasEvaluation = hasEvaluation;
    }

    public Set<Student> getStudents() {
        return students;
    }

    public void setStudents(Set<Student> students) {
        this.students = students;
    }

    public Set<Student> getHasEvaluationStudents() {
        return hasEvaluationStudents;
    }

    public void setHasEvaluationStudents(Set<Student> hasEvaluationStudents) {
        this.hasEvaluationStudents = hasEvaluationStudents;
    }

    public Set<EvaluationCard> getEvaluationCards() {
        return evaluationCards;
    }

    public void setEvaluationCards(Set<EvaluationCard> evaluationCards) {
        this.evaluationCards = evaluationCards;
    }

    public String getClassPlace() {
        return classPlace;
    }

    public void setClassPlace(String classPlace) {
        this.classPlace = classPlace;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public String getCourseInfo() {
        return courseInfo;
    }

    public void setCourseInfo(String courseInfo) {
        this.courseInfo = courseInfo;
    }
}
