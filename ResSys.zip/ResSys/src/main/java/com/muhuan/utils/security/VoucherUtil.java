package com.muhuan.utils.security;

/**
 * @author young
 * @ClassName: VoucherUtil
 * @Description: TODO(凭证码工具)
 * @date 2018/10/29 15:54
 */
public class VoucherUtil {
    /**
     * 生成凭证码
     * @param param 生成参数
     * @return 凭证码
     */
    public static String generateVoucher(String param){
//        待完善
        return "ASDFHASUIOFGHO";
    }

    /**
     *
     * @param voucher
     * @return
     */
    public static String parserVoucher(String voucher){
//        待完善
        return "解析结果";
    }
}
