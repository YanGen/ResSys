package com.muhuan.utils;

import org.apache.struts2.interceptor.SessionAware;

import java.util.Map;

/**
 * Created by young on 2018/6/20.
 */
public class CurrentUserUtils implements SessionAware {
    private Map<String, Object> session;


    @Override
    public void setSession(Map<String, Object> session) {
        this.session = session;
    }


    //    获取登录用户,待更改
    public  Object getLoginUser(){
        return session.get("key");
    }
}
