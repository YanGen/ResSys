package com.muhuan.utils;

import com.muhuan.exception.SystemException;
import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.interceptor.AbstractInterceptor;
import org.apache.struts2.ServletActionContext;

/**
 * Created by young on 2018/9/23.
 */
public class ExceptionInterceptor extends AbstractInterceptor {
    public String intercept(ActionInvocation invocation) throws Exception {
        try {
            return invocation.invoke();
        } catch (SystemException e) {
            //记录日志
            ActionSupport as = (ActionSupport) invocation.getAction();
            as.addActionError(as.getText(e.getMessage()));
            ServletActionContext.getContext().getSession().put("flag", "yes");
            //等待Struts.xml 定义
            return "systemerror";
        } catch (Exception e) {
            ActionSupport as = (ActionSupport) invocation.getAction();
            as.addActionError("对不起，服务器有点累了，请联系管理员！");
            ServletActionContext.getContext().getSession().put("flag", "yes");
            System.out.println(e.getStackTrace());
            return "systemerror";
        }
    }

}
