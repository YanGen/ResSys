package com.muhuan.utils.json;

/**
 * @author young
 * @ClassName: MapAreaIdBean
 * @Description: TODO()
 * @date 2019/2/24 16:55
 */
public class MapAreaIdBean {
    private String value;
    private String key;

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }
}
