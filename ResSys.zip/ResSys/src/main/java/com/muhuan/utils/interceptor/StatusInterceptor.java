package com.muhuan.utils.interceptor;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.ActionProxy;
import com.opensymphony.xwork2.interceptor.MethodFilterInterceptor;
import org.apache.struts2.ServletActionContext;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.Map;


/**
 * 状态拦截器
 * Created by young on 2018/6/20.
 */
public class StatusInterceptor extends MethodFilterInterceptor {
    private static final long serialVersionUID = 1L;
    private HttpSession session = null;
    private HttpServletRequest request = null;
    private Map<String ,Object> dataMap = new HashMap<>();
    @Override
    protected String doIntercept(ActionInvocation actionInvocation) throws Exception {
        ActionContext context = actionInvocation.getInvocationContext();
        session = ServletActionContext.getRequest().getSession();
        request = ServletActionContext.getRequest();

//        获取地址
        ActionProxy proxy = actionInvocation.getProxy();
        String actionName = proxy.getActionName();
        String namespace = proxy.getNamespace();
        String url = namespace + "/" + actionName;

        //        从session中获取参数并判断是否为空----判断是否为登录
        Object attribute = session.getAttribute("curUser");
        if(attribute == null){
            if(namespace.equals("/model/logistics") || namespace.equals("/model/classroom") ){
                dataMap.put("success",false);
                dataMap.put("to","/login.jsp");
                return "to_login_json";
            }

            return "to_login";
        }


//        命名空间分离，让这个拦截器可以应用在各模块
        if(namespace.equals("/model/device")){
            //      确保敏感动作action由管理老师发起
            if(actionName.equals("update")||actionName.equals("edit")||actionName.equals("delete")||actionName.equals("saveOneDevice")||actionInvocation.equals("saveMultiDevice")){
                Boolean teacherIsAdmin = (Boolean)session.getAttribute("teacherIsAdmin");
                if(!teacherIsAdmin){
                    request.setAttribute("Massage","无权限！");
                    return "to_index";
                }
            }
        }

        if(namespace.equals("/model/student")){
//        某些权限暂时只能学生
            if(actionName.equals("applyDevice")||actionName.equals("applyClassroom")||actionName.equals("exchangeDormitory")||actionName.equals("registerDormitory")
                    ||actionName.equals("evaluationCourse")||actionName.equals("evaluationPage")||actionName.equals("courseList")||actionName.equals("evaluationCourseList")
                    ||actionName.equals("classroomMessageList")||actionName.equals("deviceMessageList")||actionName.equals("logisticsMessageList")||actionName.equals("detail")){
                String idtt = (String) session.getAttribute("curUserIdtt");
                if(!idtt.equals("t2"))
                {
                    request.setAttribute("Massage","无权限！");
                    return "to_index";
                }
            }
        }

        if(namespace.equals("/model/teacher")){

        }
        if(namespace.equals("/model/teacher_admin")){

        }




//放行
        return actionInvocation.invoke();
    }

    public Map<String, Object> getDataMap() {
        return dataMap;
    }

    public void setDataMap(Map<String, Object> dataMap) {
        this.dataMap = dataMap;
    }
}
