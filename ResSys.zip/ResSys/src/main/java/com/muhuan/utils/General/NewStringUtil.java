package com.muhuan.utils.General;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author young
 * @ProjectName: ResSys
 * @Description: TODO()
 * @date 2018/12/9 18:53
 */
public class NewStringUtil {
//    根据时间生成的数字串
    synchronized public static String uniqueDigitLineByDate(){
        return new SimpleDateFormat("yyyyMMddHHmmssSSS").format(new Date());

    }

    public static String getSuffix(String old){
        if (old.indexOf(".")==-1){
             return "N";

         }else{
             String[] s = old.split("\\.");
             return s[s.length-1];
         }
    }
    public static String removeSuffix(String old){
        if (old.indexOf(".")==-1){
             return old;

         }else{
             String[] s = old.split("\\.");
             String s1 = "";
             for (int i = 0;i<s.length-1;i++){
                 s1 += s[i];
             }
             return s1;
         }
    }
}
