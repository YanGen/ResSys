package com.muhuan.utils.interceptor;

import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.ActionProxy;
import com.opensymphony.xwork2.interceptor.MethodFilterInterceptor;
import org.apache.struts2.ServletActionContext;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

/**
 * @author young
 * @ClassName: BeforeLoginInterceptor
 * @Description: TODO(用户执行登录操作,在赋登录状态前做一些判断)
 * @date 2018/10/22 19:25
 */
public class BeforeLoginInterceptor extends MethodFilterInterceptor {
    private static final long serialVersionUID = 1L;
    private HttpSession session = null;
    /**
     * 在request中可以获取请求的各种信息，可在此做安全过滤
     */
    private HttpServletRequest request = null;

    @Override
    protected String doIntercept(ActionInvocation actionInvocation) throws Exception {
        session = ServletActionContext.getRequest().getSession();
        request = ServletActionContext.getRequest();
        //        获取地址
        ActionProxy proxy = actionInvocation.getProxy();
        String actionName = proxy.getActionName();
        String namespace = proxy.getNamespace();
        String url = namespace + "/" + actionName;

        // login必须为post请求
        if((!request.getMethod().equals("POST"))&&actionName.equals("systemlogin")){
            request.setAttribute("Massage","请求非法！");
            return "to_index";
        }

        //        从session中获取参数并判断是否为空----判断是否为登录
        if(actionName.equals("systemlogin")){
            Object attribute = session.getAttribute("curUser");
            if (attribute != null) {
                request.setAttribute("Massage","请先退出！");
                return "to_index";
            }
        }else if (actionName.equals("systemlogout")){
            Object attribute = session.getAttribute("curUser");
            if (attribute == null) {
                request.setAttribute("Massage","请先登录！");
                return "to_index";
            }
        }



//放行
        return actionInvocation.invoke();
    }
}
