package com.muhuan.utils.json;

/**
 * @author young
 * @ClassName: HistoryTradeBean
 * @Description: TODO()
 * @date 2019/2/24 23:20
 */
public class HistoryTradeBean {
    private String createTime;
    private String orderNo;
    private String payedTime;
    private float tradeFee;

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getPayedTime() {
        return payedTime;
    }

    public void setPayedTime(String payedTime) {
        this.payedTime = payedTime;
    }

    public float getTradeFee() {
        return tradeFee;
    }

    public void setTradeFee(float tradeFee) {
        this.tradeFee = tradeFee;
    }
}
