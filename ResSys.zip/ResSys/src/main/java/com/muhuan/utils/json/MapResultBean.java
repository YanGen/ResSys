package com.muhuan.utils.json;

/**
 * @author young
 * @ClassName: MapResultBean
 * @Description: TODO()
 * @date 2019/2/24 17:24
 */
public class MapResultBean {
    private String remainPower;

    public String getRemainPower() {
        return remainPower;
    }

    public void setRemainPower(String remainPower) {
        this.remainPower = remainPower;
    }
}
