package com.muhuan.utils.General;

import java.util.Collections;
import java.util.List;

/**
 * @author young
 * @ClassName: NumberListUtil
 * @Description: TODO(取数列的平均值，最大值，最小值)
 * @date 2018/11/11 18:51
 */
public class NumberListUtil {
    public static float getNumberListAverage(List<Integer> numberList){

        int sum=0;
        int total=0;
        float avg= 0;

        for(int i=0;i<numberList.size();i++){

            sum+= numberList.get(i);
            total+=1;

        }

        if(total!=0){
            avg=sum/total;
        }

        return avg;
    }
    public static Integer getNumberListMax(List<Integer> numberList){
        return Collections.max(numberList);
    }
    public static Integer getNumberListMin(List<Integer> numberList){
        return Collections.min(numberList);
    }

}
