package com.muhuan.actions;

import com.muhuan.model.school.Student;
import com.opensymphony.xwork2.ActionSupport;
import org.apache.struts2.interceptor.SessionAware;
import org.springframework.stereotype.Controller;

import java.util.Map;

/**
 * @author young
 * @ClassName: DormAction
 * @Description: TODO()
 * @date 2018/9/29 12:50
 */
@Controller("dormAction")
public class DormAction extends ActionSupport implements SessionAware {
    private static final long serialVersionUID = 1L;

    private String repairType1;
    private String repairType2;
    private String repairType3;
    private String repairType4;

    private Map<String ,Object> session;
    @Override
    public void setSession(Map<String, Object> session) {
        this.session = session;
    }



    public String logout() throws Exception{
        System.out.println("logout");
        return "logout_success";
    }

}
