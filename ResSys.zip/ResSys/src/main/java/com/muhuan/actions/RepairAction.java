package com.muhuan.actions;

import com.muhuan.model.flow.LogisticsRepairSheet;
import com.muhuan.model.school.Building;
import com.muhuan.model.school.Global;
import com.muhuan.model.util.SchoolFile;
import com.muhuan.model.util.UploadFile;
import com.muhuan.service.BuildingService;
import com.muhuan.service.FileService;
import com.muhuan.service.RepairService;
import com.muhuan.utils.General.NewStringUtil;
import com.opensymphony.xwork2.ActionSupport;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.interceptor.RequestAware;
import org.apache.struts2.interceptor.SessionAware;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.io.File;
import java.util.*;

/**
 * @author young
 * @ProjectName: ResSys
 * @Description: TODO()
 * @date 2018/12/7 9:43
 */

@Controller
public class RepairAction  extends ActionSupport implements SessionAware, RequestAware {
    private static final long serialVersionUID = 1L;

    private File picture;
    private String pictureFileName;
    private String pictureContentType;
    private String imgList;
    private String repairArea1;
    private String repairArea2;
    private String repairArea3;
    private String repairArea4;

    private String repairPerson;
    private String repairPersonPhone;
    private String repairTime1;
    private String repairTime2;
    private String repairType1;
    private String repairType2;
    private String repairType3;
    private String repairType4;

    private String name;
    private String detail;
    private String webname;
    private String icpnum;
    private String email;
    private String telphone;
    private String file_id;


    @Autowired
    private RepairService repairService;

    @Autowired
    private FileService fileService;

    private Map<String ,Object> session;
    private Map<String ,Object> request;
    private Map<String ,Object> dataMap = new HashMap<>();
    @Autowired
    private BuildingService buildingService;

    public String repairAreaJson() throws Exception{

        Map<String,Object> repairArea = buildingService.repairAreaAll();
        dataMap.put("repairArea",repairArea);
        dataMap.put("success",true);

        return SUCCESS;
    }

    public String schoolJson() throws Exception{

        dataMap.put("success",true);

        return SUCCESS;
    }


    public String applyRepair(){
        LogisticsRepairSheet logisticsRepairSheet = new LogisticsRepairSheet();
        logisticsRepairSheet.setStatus("等待系统处理");
        logisticsRepairSheet.setPersonPhone(repairPersonPhone);
        logisticsRepairSheet.setRepairPerson(repairPerson);
        logisticsRepairSheet.setWhatDay(repairTime1);
        logisticsRepairSheet.setWhatTime(repairTime2);
        logisticsRepairSheet.setRepairDetaill(repairType4);
        Integer buildingId = Integer.valueOf(repairArea3.split("-")[1]);
        Building building = buildingService.getBuilding(buildingId);
        logisticsRepairSheet.setBuilding(building);
        logisticsRepairSheet.setBuildingDetail(repairArea4);

//        logisticsRepairSheet.setUserInfo((String)session.get("curUser"));
        List <Integer> imgIdList = new ArrayList<>();


        for(String imgId : imgList.split("-")){
            System.out.println(imgList);
            try {
                imgIdList.add(Integer.valueOf(imgId));
            }catch (Exception e){
                break;
            }

            if (imgIdList.size() == 2){
                break;
            }
        }

        for(Integer imgId : imgIdList){
            UploadFile u = fileService.getFileById(imgId);
            if(!u.equals(null)){

                Set<UploadFile> uploadFiles = logisticsRepairSheet.getPictures();
                uploadFiles.add(u);
                logisticsRepairSheet.setPictures(uploadFiles);

            }
        }
        System.out.println(logisticsRepairSheet.toString());
        repairService.applyLogisticsRepairSheet(logisticsRepairSheet);
        dataMap.put("success",true);
        return SUCCESS;
    }

        public String schoolRepair(){
        Global global = new Global();
        global.setName(name);
        global.setDetail(detail);
        global.setIcpnum(icpnum);
        global.setEmail(email);
        global.setTelphone(telphone);
        global.setWebname(webname);



//        logisticsRepairSheet.setUserInfo((String)session.get("curUser"));
        List <Integer> imgIdList = new ArrayList<>();


        for(String imgId : imgList.split("-")){
            System.out.println(imgList);
            try {
                imgIdList.add(Integer.valueOf(imgId));
            }catch (Exception e){
                break;
            }

            if (imgIdList.size() == 2){
                break;
            }
        }

        for(Integer imgId : imgIdList){
            SchoolFile u = fileService.getSchoolFileById(imgId);
            if(!u.equals(null)){

                Set<SchoolFile> schoolFiles = global.getPictures();
                schoolFiles.add(u);
                global.setPictures(schoolFiles);

            }
        }
        System.out.println(global.toString());
        repairService.applySchoolRepairSheet(global);
        dataMap.put("success",true);
        return SUCCESS;
    }

    public String upload() throws Exception {

        String userName = (String) session.get("curUser");

        System.out.println(pictureFileName);

        UploadFile file = new UploadFile();
        file.setOldName(pictureFileName);
        file.setPath("/upload/img");
        file.setFromUser(userName);
        file.setPostIp(ServletActionContext.getRequest().getRemoteAddr());
        file.setPostUA(ServletActionContext.getRequest().getRemoteUser());
        file.setPostDate(new Date());
        file.setFileContentType(pictureContentType);
        file.setSuffix(NewStringUtil.getSuffix(pictureFileName));
        file.setNewName(NewStringUtil.uniqueDigitLineByDate());

        //
        // 提供一个服务器的存放地址即可
        String realPath = ServletActionContext.getServletContext().getRealPath("/ccddnn/upload/img");

//        try {
            String result = fileService.savaFile(picture,file,realPath);
            dataMap.put("fileId",result);
            dataMap.put("success",true);
//        }catch (Exception e){
//            dataMap.put("success",false);
//        }


        return SUCCESS;
    }

        public String schoolupload() throws Exception {


        System.out.println(pictureFileName);

        SchoolFile file = new SchoolFile();
        file.setOldName(pictureFileName);
        file.setPath("/schoolupload/img");
        file.setPostIp(ServletActionContext.getRequest().getRemoteAddr());
        file.setPostUA(ServletActionContext.getRequest().getRemoteUser());
        file.setPostDate(new Date());
        file.setFileContentType(pictureContentType);
        file.setSuffix(NewStringUtil.getSuffix(pictureFileName));
        file.setNewName(NewStringUtil.uniqueDigitLineByDate());

        //
        // 提供一个服务器的存放地址即可
        String realPath = ServletActionContext.getServletContext().getRealPath("/ccddnn/schoolupload/img");

//        try {
            String result = fileService.savaSchoolFile(picture,file,realPath);
            dataMap.put("fileId",result);
            dataMap.put("success",true);
//        }catch (Exception e){
//            dataMap.put("success",false);
//        }


        return SUCCESS;
    }



    public void setImgList(String imgList) {
        this.imgList = imgList;
    }

    public void setRepairArea1(String repairArea1) {
        this.repairArea1 = repairArea1;
    }

    public void setRepairArea2(String repairArea2) {
        this.repairArea2 = repairArea2;
    }

    public void setRepairArea3(String repairArea3) {
        this.repairArea3 = repairArea3;
    }

    public void setRepairArea4(String repairArea4) {
        this.repairArea4 = repairArea4;
    }

    public void setRepairPerson(String repairPerson) {
        this.repairPerson = repairPerson;
    }

    public void setRepairPersonPhone(String repairPersonPhone) {
        this.repairPersonPhone = repairPersonPhone;
    }

    public void setRepairTime1(String repairTime1) {
        this.repairTime1 = repairTime1;
    }

    public void setRepairTime2(String repairTime2) {
        this.repairTime2 = repairTime2;
    }

    public void setRepairType1(String repairType1) {
        this.repairType1 = repairType1;
    }

    public void setRepairType2(String repairType2) {
        this.repairType2 = repairType2;
    }

    public void setRepairType3(String repairType3) {
        this.repairType3 = repairType3;
    }

    public void setRepairType4(String repairType4) {
        this.repairType4 = repairType4;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    public String getWebname() {
        return webname;
    }

    public void setWebname(String webname) {
        this.webname = webname;
    }

    public String getIcpnum() {
        return icpnum;
    }

    public void setIcpnum(String icpnum) {
        this.icpnum = icpnum;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelphone() {
        return telphone;
    }

    public void setTelphone(String telphone) {
        this.telphone = telphone;
    }

    public String getFile_id() {
        return file_id;
    }

    public void setFile_id(String file_id) {
        this.file_id = file_id;
    }

    public void setRepairService(RepairService repairService) {
        this.repairService = repairService;
    }

    public void setFileService(FileService fileService) {
        this.fileService = fileService;
    }

    public void setBuildingService(BuildingService buildingService) {
        this.buildingService = buildingService;
    }

    public void setPicture(File picture) {
        this.picture = picture;
    }

    public void setPictureFileName(String pictureFileName) {
        this.pictureFileName = pictureFileName;
    }

    public void setPictureContentType(String pictureContentType) {
        this.pictureContentType = pictureContentType;
    }

    public Map<String, Object> getDataMap() {
        return dataMap;
    }

    public void setDataMap(Map<String, Object> dataMap) {
        this.dataMap = dataMap;
    }

    @Override
    public void setSession(Map<String, Object> session) {
        this.session = session;
    }

    @Override
    public void setRequest(Map<String, Object> request) {
        this.request = request;
    }
}
