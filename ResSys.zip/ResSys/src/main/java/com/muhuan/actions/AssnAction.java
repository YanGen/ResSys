package com.muhuan.actions;

import org.springframework.stereotype.Controller;

/**
 * @author young
 * @ProjectName: ResSys
 * @Description: TODO()
 * @date 2019/3/1 10:48
 */

@Controller("assnAction")
public class AssnAction {

        private static final long serialVersionUID = 1L;

    public String assnShow() {

        return "to_assn_show_page";
    }
}
