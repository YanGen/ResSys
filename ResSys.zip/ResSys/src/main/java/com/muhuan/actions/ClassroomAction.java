package com.muhuan.actions;

import com.muhuan.service.BuildingService;
import com.muhuan.service.ClassroomService;
import com.opensymphony.xwork2.ActionSupport;
import org.apache.struts2.interceptor.RequestAware;
import org.apache.struts2.interceptor.SessionAware;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Controller
public class ClassroomAction extends ActionSupport implements SessionAware,RequestAware {
    private static final long serialVersionUID = 1L;
    private Map<String ,Object> session;
    private Map<String ,Object> request;

    private Date startTime;
    private Date endTime;
    private String classroomArea1;
    private String classroomArea2;
    private String classroomArea3;
    private String classroomArea4;

    private Map<String ,Object> dataMap = new HashMap<>();
    @Autowired
    private ClassroomService classroomService;
    @Autowired
    private BuildingService buildingService;

    public String checkClassroomTimeAllow(){
        String buildId = classroomArea3.split("-")[1];
        String buildNumber = classroomArea3.split("-")[2];
        Boolean result = classroomService.checkClassroomTimeAllow(startTime,endTime,buildId,buildNumber);
        dataMap.put("allow",result);
        dataMap.put("success",true);
        return SUCCESS;
    }

    public String classroomAreaJson() throws Exception{

        Map<String,Object> classroomArea = buildingService.classroomAreaAll();
        dataMap.put("classroomArea",classroomArea);
        dataMap.put("success",true);

        return SUCCESS;
    }

    @Override
    public void setSession(Map<String, Object> session) {
        this.session = session;
    }

    @Override
    public void setRequest(Map<String, Object> request) {
        this.request = request;
    }

    public Map<String, Object> getDataMap() {
        return dataMap;
    }

    public void setDataMap(Map<String, Object> dataMap) {
        this.dataMap = dataMap;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public String getClassroomArea1() {
        return classroomArea1;
    }

    public void setClassroomArea1(String classroomArea1) {
        this.classroomArea1 = classroomArea1;
    }

    public String getClassroomArea2() {
        return classroomArea2;
    }

    public void setClassroomArea2(String classroomArea2) {
        this.classroomArea2 = classroomArea2;
    }

    public String getClassroomArea3() {
        return classroomArea3;
    }

    public void setClassroomArea3(String classroomArea3) {
        this.classroomArea3 = classroomArea3;
    }

    public String getClassroomArea4() {
        return classroomArea4;
    }

    public void setClassroomArea4(String classroomArea4) {
        this.classroomArea4 = classroomArea4;
    }
}
