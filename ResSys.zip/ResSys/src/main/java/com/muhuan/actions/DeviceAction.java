package com.muhuan.actions;

import com.muhuan.model.basic.Device;
import com.muhuan.model.basic.DevicePicture;
import com.muhuan.model.basic.Dormitory;
import com.muhuan.model.util.Pager;
import com.muhuan.service.DeviceService;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;
import org.apache.struts2.interceptor.RequestAware;
import org.apache.struts2.interceptor.SessionAware;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.io.Serializable;
import java.util.*;

/**
 * @author young
 * @ClassName: DeviceAction
 * @Description: TODO()
 * @date 2018/10/18 19:26
 */
@Controller("deviceAction")
public class DeviceAction extends ActionSupport implements SessionAware,RequestAware,ModelDriven<Device>{
    private static final long serialVersionUID = 1L;
    private Map<String ,Object> session;
    private Map<String ,Object> request;
    @Autowired
    private DeviceService deviceService;
    private Device device = new Device();
    private String imglink;
    private Integer deviceId;
    private String pg;
    private Integer studentId;
    private Integer applyNum;

    public String apply(){
        Boolean applyResult = deviceService.apply(deviceId,studentId,applyNum);
        if (applyResult){
            request.put("Massage","申请成功！");
            return "apply_success";
        }else {
            request.put("Massage","");
            return "apply_error";
        }

    }

    public String update(){
        deviceService.update(device);
        return "update_success";
    }

    public String edit(){
        request.put("editDevice",deviceService.getById(deviceId));
        if (pg == null){
            pg = "1";
        }
        return "to_edit";
    }


    public String list(){
        if (pg == null){
            pg = "1";
        }
        Integer total = deviceService.total();
        Pager<Device> devicePager = new Pager<>();
        devicePager.setStart((Integer.valueOf(pg)-1)*10);
        devicePager.setPageSize(10);
        devicePager.setTotalCount(total);
        List<Device> deviceList = deviceService.list(devicePager);
        request.put("devices",deviceList);
        request.put("page",devicePager);
        String curUserIdtt = (String)session.get("curUserIdtt");
        boolean teacherIsAdmin = (boolean) session.get("teacherIsAdmin");
        if(curUserIdtt.equals("t3")&& teacherIsAdmin){
            return "teacher_admin_list";
        }
        return "list";
    }

    public String delete(){
        if (pg != null){
            session.put("curPG",pg);
        }else {
            session.put("curPG","1");
        }
        deviceService.delete(deviceId);
        return "delete_success";
    }


    public String saveOneDevice(){

        device.setMargin(1);
        device.setNumber(1);

        if (!(imglink == null)){
            DevicePicture devicePicture = new DevicePicture();
            devicePicture.setLink(imglink);
            devicePicture.setName("图片");
            devicePicture.setDevice(device);
            Set<DevicePicture> devicePictures = new HashSet<>();
            devicePictures.add(devicePicture);
            device.setDevicePictures(devicePictures);
        }
        deviceService.saveOne(device);
        return "save_one_device";
    }
    public String saveMultiDevice(){

        device.setMargin(device.getNumber());

        if (!(imglink == null)){
            DevicePicture devicePicture = new DevicePicture();
            devicePicture.setLink(imglink);
            devicePicture.setName("图片");
            devicePicture.setDevice(device);
            Set<DevicePicture> devicePictures = new HashSet<>();
            devicePictures.add(devicePicture);
            device.setDevicePictures(devicePictures);
        }


        deviceService.saveOne(device);
        return "save_multi_device";
    }

    public Map<String, Object> getSession() {
        return session;
    }

    public Integer getStudentId() {
        return studentId;
    }

    public void setStudentId(Integer studentId) {
        this.studentId = studentId;
    }

    public Integer getApplyNum() {
        return applyNum;
    }

    public void setApplyNum(Integer applyNum) {
        this.applyNum = applyNum;
    }

    public Integer getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(Integer deviceId) {
        this.deviceId = deviceId;
    }

    public String getPg() {
        return pg;
    }

    public void setPg(String pg) {
        this.pg = pg;
    }

    @Override
    public void setSession(Map<String, Object> session) {

        this.session = session;
    }

    @Override
    public void setRequest(Map<String, Object> request) {
        this.request = request;
    }
    @Override
    public Device getModel() {
        return device;
    }

    public String getImglink() {
        return imglink;
    }

    public void setImglink(String imglink) {
        this.imglink = imglink;
    }

}
