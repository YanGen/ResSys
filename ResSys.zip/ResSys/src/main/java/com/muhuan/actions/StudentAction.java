package com.muhuan.actions;

import com.muhuan.model.basic.Course;
import com.muhuan.model.basic.Device;
import com.muhuan.model.basic.Dormitory;
import com.muhuan.model.basic.EvaluationCard;
import com.muhuan.model.flow.ClassroomApplySheet;
import com.muhuan.model.flow.DeviceApplySheet;
import com.muhuan.model.flow.DormExchangeSheet;
import com.muhuan.model.flow.LogisticsRepairSheet;
import com.muhuan.model.school.Building;
import com.muhuan.model.school.Student;
import com.muhuan.model.util.Pager;
import com.muhuan.model.util.UploadFile;
import com.muhuan.service.*;
import com.opensymphony.xwork2.ActionSupport;
import org.apache.struts2.interceptor.RequestAware;
import org.apache.struts2.interceptor.SessionAware;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.util.*;

/**
 * @author young
 * @ClassName: StudentAction
 * @Description: TODO()
 * @date 2018/10/22 20:40
 */
@Controller("studentAction")
public class StudentAction  extends ActionSupport implements SessionAware,RequestAware{
    private static final long serialVersionUID = 1L;
    private Map<String ,Object> session;
    private Map<String ,Object> request;
    @Autowired
    private EvaluationService evaluationService;
    @Autowired
    private DeviceService deviceService;
    @Autowired
    private StudentService studentService;
    @Autowired
    private DormService dormService;
    @Autowired
    private BuildingService buildingService;
    private String pg = "1";
    private Integer deviceId;
    private Integer applyNumber;
    private String teacherCode;
    private Date revertDate;
    private Integer courseId;
    private String courseName;
    private String[] itemScore;
    private Integer teacherId;
    private String teacherName;
    private String oldArea1;
    private String repairArea1;
    private String repairArea2;
    private String repairArea3;
    private String repairArea4;

    private String applyPerson;
    private String applyPersonPhone;
    private String classroomArea1;
    private String classroomArea2;
    private String classroomArea3;
    private String classroomArea4;
    private Date endTime;
    private Date startTime;
    private String reason;
    private Integer id;
    private String picture;


    private String selectClassroom = "";
    private String selectDormExchange = "";
    private String selectLogistics = "";
    private String check = "";



    public String applyClassroom() throws Exception {
        Student student = (Student)session.get("curStudent");

        String buildId = classroomArea3.split("-")[1];
        String buildNumber = classroomArea3.split("-")[2];

        studentService.applyClassroom(student,buildId,buildNumber,startTime,endTime,reason,classroomArea4,applyPerson,applyPersonPhone);
        return SUCCESS;
    }

    public String exchangeDormitory(){
        Student student = (Student) session.get("curStudent");
        if (student.getDormitory()==null){
            request.put("Massage","未登记宿舍~");
            return "already_register";
        }

        Dormitory dormitory = student.getDormitory();
        String dormitoryString = dormitory.getBuilding().getName()+"-"+dormitory.getBuildingNumber()+"号-"+dormitory.getRoomNumber()+"房";
        String buildId = repairArea3.split("-")[1];
        String buildNumber = repairArea3.split("-")[2];
        dormService.applyExchangeDormitory(student,buildId,buildNumber,repairArea4,dormitoryString);

        return "apply_exchange_dormitory";
    }


    public String registerDormitory(){

        Student student = (Student) session.get("curStudent");
        if (student.getDormitory()!=null){
            request.put("Massage","不可重复登记~");
            return "already_register";
        }
        String buildId = repairArea3.split("-")[1];
        String buildNumber = repairArea3.split("-")[2];

        dormService.registerDormitory(student,buildId,buildNumber,repairArea4);

        return "register_dormitory";
    }
    public String evaluationCourse(){

        System.out.println(itemScore.length);

        System.out.println("evaluationCourse");
        System.out.println("取Card");
        EvaluationCard evaluationCard = studentService.getEvaluationCardWithCourseInfo(courseId);
        System.out.println("开始取课程");
        Course evaluationCourse = studentService.getEvaluationCourseById(courseId);
        System.out.println("取当前状态");
        Student curStudent = (Student) session.get("curStudent");
        System.out.println("检查Card");
        Boolean result = studentService.evaluationCardCheck(evaluationCard,evaluationCourse,curStudent,itemScore);
        return  result ? "evaluation_success" : "evaluation_error";
    }

    public String evaluationPage(){
        System.out.println("evaluationPage");
        Course evaluationCourse = studentService.getEvaluationCourseById(courseId);
        EvaluationCard evaluationCard = studentService.getEvaluationCardWithCourseInfo(courseId);
        request.put("evaluationCourse",evaluationCourse);
        request.put("evaluationCard",evaluationCard);

        return "to_evaluation_page";
    }

    public String courseList(){

        System.out.println("courseList");

        Student curStudent = (Student) session.get("curStudent");


        Pager <Course> coursePager = new Pager<>();
        Set<Course> courses = studentService.curStudentEvaluationCourseList(curStudent);
        coursePager.setStart((Integer.valueOf(pg)-1)*10);
        coursePager.setPageSize(10);
        coursePager.setTotalCount(courses.size());
        request.put("courses",courses);
        request.put("page",coursePager);

        return "course_list";
    }

    public String evaluationCourseList(){
        Student curStudent = (Student) session.get("curStudent");

        Pager <Course> coursePager = new Pager<>();
        Set<Course> courses = studentService.curStudentCourseList(curStudent);
        for(Course eachCourse: courses){
            if(!eachCourse.getStartEvaluation()){
                courses.remove(eachCourse);
            }

            for(Student studentItem : eachCourse.getHasEvaluationStudents()){
                System.out.println(studentItem.getSid());
                if (studentItem.getSid().equals(curStudent.getSid())){
                    courses.remove(eachCourse);
                    break;
                }
            }
        }
        coursePager.setStart((Integer.valueOf(pg)-1)*10);
        coursePager.setPageSize(10);
        coursePager.setTotalCount(courses.size());

        request.put("courses",courses);
        request.put("page",coursePager);


        return "evaluation_course_list";
    }



    public String applyDevice(){

        Student student = (Student)session.get("curStudent");
        Device device = deviceService.getById(deviceId);
        if (device == null){
            request.put("Massage","设备不存在！");
            return "apply_fail";
        }else {
            if(applyNumber > device.getMargin()){
                request.put("Massage","余量不足！");
            }
        }

        DeviceApplySheet deviceApplySheet = new DeviceApplySheet();
        deviceApplySheet.setDevice(device);
        deviceApplySheet.setApplyNum(applyNumber);
        deviceApplySheet.setRevertDate(revertDate);
        deviceApplySheet.setTeacherCode(teacherCode);
        deviceApplySheet.setStudentId(student.getSid());
        deviceApplySheet.setStudentName(student.getName());
        studentService.generateDeviceApplySheet(deviceApplySheet);

        return "apply_success";
    }

    public String classroomMessageList() {

            List<ClassroomApplySheet> classroomApplySheets = studentService.getClassroomApplySheetList();
            request.put("classroomApplySheets", classroomApplySheets);

        return "classroom_list";
    }

        public String deviceMessageList() {

            List<DormExchangeSheet> dormExchangeSheets = studentService.getDormExchangeSheetList();
            request.put("dormExchangeSheets", dormExchangeSheets);

        return "device_list";
    }

        public String logisticsMessageList() {

            List<LogisticsRepairSheet> logisticsRepairSheets = studentService.getLogisticsRepairSheetList();
            request.put("logisticsRepairSheets", logisticsRepairSheets);

        return "logistics_list";
    }

    public String detail() {

        if (check.equals("classroom")){
            ClassroomApplySheet classroomApplySheet = studentService.getClassroomApplySheet(id);
            request.put("classroomApplySheet", classroomApplySheet);


        }
        if (check.equals("device")){
            DormExchangeSheet dormExchangeSheet = studentService.getDormExchangeSheet(id);
            request.put("dormExchangeSheet", dormExchangeSheet);


        }
        if (check.equals("logistics")){
            LogisticsRepairSheet logisticsRepairSheet = studentService.getLogisticsRepairSheet(id);
            Set<UploadFile> imgs = logisticsRepairSheet.getPictures();
            for(UploadFile img :imgs){
                request.put("picture", img.getNewName());
            }
            request.put("logisticsRepairSheet", logisticsRepairSheet);


        }

        return "success_detail";
    }


    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public String[] getItemScore() {
        return itemScore;
    }

    public void setItemScore(String[] itemScore) {
        this.itemScore = itemScore;
    }

    public Integer getTeacherId() {
        return teacherId;
    }

    public void setTeacherId(Integer teacherId) {
        this.teacherId = teacherId;
    }

    public String getTeacherName() {
        return teacherName;
    }

    public void setTeacherName(String teacherName) {
        this.teacherName = teacherName;
    }

    public Integer getCourseId() {
        return courseId;
    }

    public void setCourseId(Integer courseId) {
        this.courseId = courseId;
    }

    public String getPg() {
        return pg;
    }

    public void setPg(String pg) {
        this.pg = pg;
    }

    public Integer getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(Integer deviceId) {
        this.deviceId = deviceId;
    }

    public Integer getApplyNumber() {
        return applyNumber;
    }

    public void setApplyNumber(Integer applyNumber) {
        this.applyNumber = applyNumber;
    }

    public String getTeacherCode() {
        return teacherCode;
    }

    public void setTeacherCode(String teacherCode) {
        this.teacherCode = teacherCode;
    }

    public Date getRevertDate() {
        return revertDate;
    }

    public void setRevertDate(Date revertDate) {
        this.revertDate = revertDate;
    }

    public Map<String, Object> getSession() {
        return session;
    }

    @Override
    public void setSession(Map<String, Object> session) {
        this.session = session;
    }

    public Map<String, Object> getRequest() {
        return request;
    }

    @Override
    public void setRequest(Map<String, Object> request) {
        this.request = request;
    }

    public String getRepairArea1() {
        return repairArea1;
    }

    public void setRepairArea1(String repairArea1) {
        this.repairArea1 = repairArea1;
    }

    public String getRepairArea2() {
        return repairArea2;
    }

    public void setRepairArea2(String repairArea2) {
        this.repairArea2 = repairArea2;
    }

    public String getRepairArea3() {
        return repairArea3;
    }

    public void setRepairArea3(String repairArea3) {
        this.repairArea3 = repairArea3;
    }

    public String getRepairArea4() {
        return repairArea4;
    }

    public void setRepairArea4(String repairArea4) {
        this.repairArea4 = repairArea4;
    }

    public String getOldArea1() {
        return oldArea1;
    }

    public void setOldArea1(String oldArea1) {
        this.oldArea1 = oldArea1;
    }

    public String getApplyPerson() {
        return applyPerson;
    }

    public void setApplyPerson(String applyPerson) {
        this.applyPerson = applyPerson;
    }

    public String getApplyPersonPhone() {
        return applyPersonPhone;
    }

    public void setApplyPersonPhone(String applyPersonPhone) {
        this.applyPersonPhone = applyPersonPhone;
    }

    public String getClassroomArea1() {
        return classroomArea1;
    }

    public void setClassroomArea1(String classroomArea1) {
        this.classroomArea1 = classroomArea1;
    }

    public String getClassroomArea2() {
        return classroomArea2;
    }

    public void setClassroomArea2(String classroomArea2) {
        this.classroomArea2 = classroomArea2;
    }

    public String getClassroomArea3() {
        return classroomArea3;
    }

    public void setClassroomArea3(String classroomArea3) {
        this.classroomArea3 = classroomArea3;
    }

    public String getClassroomArea4() {
        return classroomArea4;
    }

    public void setClassroomArea4(String classroomArea4) {
        this.classroomArea4 = classroomArea4;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getSelectClassroom() {
        return selectClassroom;
    }

    public void setSelectClassroom(String selectClassroom) {
        this.selectClassroom = selectClassroom;
    }

    public String getSelectDormExchange() {
        return selectDormExchange;
    }

    public void setSelectDormExchange(String selectDormExchange) {
        this.selectDormExchange = selectDormExchange;
    }

    public String getSelectLogistics() {
        return selectLogistics;
    }

    public void setSelectLogistics(String selectLogistics) {
        this.selectLogistics = selectLogistics;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCheck() {
        return check;
    }

    public void setCheck(String check) {
        this.check = check;
    }

    public String getPicture() {
        return picture;
    }

    public void setPicture(String picture) {
        this.picture = picture;
    }
}
