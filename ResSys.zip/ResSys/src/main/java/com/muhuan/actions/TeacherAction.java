package com.muhuan.actions;

import com.muhuan.model.flow.ClassroomApplySheet;
import com.muhuan.model.flow.DeviceApplyReceiptSheet;
import com.muhuan.model.flow.DeviceApplySheet;
import com.muhuan.model.school.Teacher;
import com.muhuan.model.util.Pager;
import com.muhuan.service.DeviceService;
import com.muhuan.service.TeacherService;
import com.opensymphony.xwork2.ActionSupport;
import org.apache.struts2.interceptor.RequestAware;
import org.apache.struts2.interceptor.SessionAware;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.util.List;
import java.util.Map;

/**
 * @author young
 * @ClassName: TeacherAction
 * @Description: TODO()
 * @date 2018/10/26 9:44
 */
@Controller("teacherAction")
public class TeacherAction extends ActionSupport implements SessionAware,RequestAware {

    private Map<String ,Object> session;
    private Map<String ,Object> request;
    @Autowired
    private DeviceService deviceService;
    @Autowired
    private TeacherService teacherService;
    private String pg = "1";
    private Integer sheetId;

    public String proveClassroomApplyList(){
        Teacher curTeacher = (Teacher) session.get("curTeacher");
        String teacherCode = curTeacher.getTeacherCode();
        Pager<ClassroomApplySheet> sheetPager = new Pager<>();
        sheetPager.setStart((Integer.valueOf(pg)-1)*10);
        sheetPager.setPageSize(10);
        List<ClassroomApplySheet> classroomApplySheets = teacherService.getProveClassroomApplyList(teacherCode,sheetPager);
        sheetPager.setTotalCount(((List) classroomApplySheets).size());
        request.put("classroomApplySheets",classroomApplySheets);
        request.put("page",sheetPager);
        return "prove_classroom_list";
    }

    public String proveClassroomApply(){
        teacherService.proveClassroomApply(sheetId);
        return "prove_classroom_success";
    }
    public String disproveClassroomApply(){
        ClassroomApplySheet classroomApplySheet = new ClassroomApplySheet();
        classroomApplySheet.setIllustrate("签字老师不同意,请联系相应老师。");
        classroomApplySheet.setResult("不通过");
        classroomApplySheet.setTeacherName((String)session.get("curUser"));
        classroomApplySheet.setTeacherId(String.valueOf(((Teacher)session.get("curTeacher")).getId()));
        teacherService.disproveClassroomApply(sheetId,classroomApplySheet);
        return "disprove_classroom_success";
    }

    public String proveDeviceApplyList(){
        Teacher curTeacher = (Teacher) session.get("curTeacher");
        String teacherCode = curTeacher.getTeacherCode();
        Pager<DeviceApplySheet> sheetPager = new Pager<>();
        sheetPager.setStart((Integer.valueOf(pg)-1)*10);
        sheetPager.setPageSize(10);
        List<DeviceApplySheet> deviceApplySheetList = teacherService.getProveDeviceApplyList(teacherCode,sheetPager);
        sheetPager.setTotalCount(((List) deviceApplySheetList).size());
        request.put("deviceApplySheetList",deviceApplySheetList);
        request.put("page",sheetPager);
        return "list";

    }

    public String proveDeviceApply(){
        teacherService.proveDeviceApply(sheetId);
        return "prove_success";
    }

    public String disproveDeviceApply(){
//        签字老师不同意，生成回执还给学生
        DeviceApplyReceiptSheet deviceApplyReceiptSheet = new DeviceApplyReceiptSheet();
        deviceApplyReceiptSheet.setIllustrate("签字老师不同意,请联系相应老师。");
        deviceApplyReceiptSheet.setResult("不通过");
        deviceApplyReceiptSheet.setTeacherName((String)session.get("curUser"));
        deviceApplyReceiptSheet.setTeacherId(((Teacher)session.get("curTeacher")).getId());
        teacherService.disproveDeviceApply(sheetId,deviceApplyReceiptSheet);
        return "disprove_success";
    }

    public Integer getSheetId() {
        return sheetId;
    }

    public void setSheetId(Integer sheetId) {
        this.sheetId = sheetId;
    }

    public String getPg() {
        return pg;
    }

    public void setPg(String pg) {
        this.pg = pg;
    }

    @Override
    public void setSession(Map<String, Object> session) {
        this.session = session;
    }

    @Override
    public void setRequest(Map<String, Object> request) {
        this.request = request;
    }
}
