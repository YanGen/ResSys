package com.muhuan.actions;

import org.omg.CORBA.PUBLIC_MEMBER;
import org.springframework.stereotype.Controller;

/**
 * @author young
 * @ProjectName: ResSys
 * @Description: TODO()
 * @date 2019/3/1 10:43
 */

@Controller("areaAction")
public class AreaAction {

    private static final long serialVersionUID = 1L;

    public String areaShow() {

        return "to_area_show_page";
    }
}
