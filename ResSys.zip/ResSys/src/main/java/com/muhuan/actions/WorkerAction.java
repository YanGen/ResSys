package com.muhuan.actions;

import com.muhuan.model.flow.LogisticsRepairSheet;
import com.muhuan.service.RepairService;
import com.opensymphony.xwork2.ActionSupport;
import org.apache.struts2.interceptor.RequestAware;
import org.apache.struts2.interceptor.SessionAware;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author young
 * @ProjectName: ResSys
 * @Description: TODO()
 * @date 2019/1/3 18:41
 */
@Controller
public class WorkerAction extends ActionSupport implements SessionAware, RequestAware {
    private static final long serialVersionUID = 1L;
    private Map<String ,Object> session;
    private Map<String ,Object> request;
    private Map<String ,Object> dataMap = new HashMap<>();
    @Autowired
    private RepairService repairService;


    public String repairApplyList(){

        List<LogisticsRepairSheet> logisticsRepairSheetList = repairService.workerRepairSheetList();

        System.out.println(logisticsRepairSheetList.size());

        dataMap.put("logisticsRepairSheetList",logisticsRepairSheetList);

        dataMap.put("success",true);
        return SUCCESS;
    }

    public Map<String, Object> getSession() {
        return session;
    }

    @Override
    public void setSession(Map<String, Object> session) {
        this.session = session;
    }

    public Map<String, Object> getRequest() {
        return request;
    }

    @Override
    public void setRequest(Map<String, Object> request) {
        this.request = request;
    }

    public Map<String, Object> getDataMap() {
        return dataMap;
    }

    public void setDataMap(Map<String, Object> dataMap) {
        this.dataMap = dataMap;
    }
}
