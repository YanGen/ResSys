package com.muhuan.actions;

import com.muhuan.dao.TeacherDao;
import com.muhuan.model.basic.Classroom;
import com.muhuan.model.basic.Course;
import com.muhuan.model.flow.*;
import com.muhuan.model.school.*;
import com.muhuan.model.util.Pager;
import com.muhuan.model.util.UploadFile;
import com.muhuan.service.*;
import com.opensymphony.xwork2.ActionSupport;
import org.apache.struts2.interceptor.RequestAware;
import org.apache.struts2.interceptor.SessionAware;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import javax.persistence.Table;
import java.util.*;

/**
 * @author young
 * @ClassName: TeacherAdminAction
 * @Description: TODO()
 * @date 2018/10/18 22:06
 */
@Controller("teacherAdminAction")
public class TeacherAdminAction extends ActionSupport implements SessionAware,RequestAware {
    private Map<String ,Object> session;
    private Map<String ,Object> request;

    @Autowired
    private DeviceService deviceService;
    @Autowired
    private TeacherAdminService teacherAdminService;
    @Autowired
    private DormService dormService;
    @Autowired
    private StudentService studentService;
    @Autowired
    private TeacherService teacherService;
    @Autowired
    private WorkerService workerService;

    private String pg = "1";
    private Integer sheetId;
    private String illustrate="默认无";
    private Date voucherDate;
    private Integer allowNum=1;
    private Integer courseId;
    private Integer StuNum;
    private String name;
    private Map<String,Object> dataMap = new HashMap<>();
    private Integer id;
    private Integer sid;

    private String sex;
    private String grade;
    private String unit;
    private String studentCode;
    private String teacherCode;
    private String phoneNumber;
    private String password;
    private String check="";

    private Integer teacherId;
    private String courseName;
    private String classPlace;
    private String courseInfo;
    private String stuNumList;


    public String proveDormExchangeApply(){
        Teacher curTeacher = (Teacher) session.get("curTeacher");
        dormService.exchangeStudentDormitory(sheetId,curTeacher.getTeacherCode());
        return "prove_dorm_exchange_apply";
    }
    public String disproveDormExchangeApply(){
        Teacher curTeacher = (Teacher) session.get("curTeacher");
        dormService.disExchangeStudentDormitory(sheetId,curTeacher.getTeacherCode());
        return "prove_dorm_exchange_apply";
    }

    public String proveDormExchangeApplyList(){

        Pager <DormExchangeSheet> pager = new Pager<>();
        pager.setStart(0);
        pager.setPageSize(100);
        List<DormExchangeSheet> dormExchangeSheets = dormService.notProveDormExchangeApplyList(pager);
        request.put("dormExchangeSheets",dormExchangeSheets);
        request.put("page",pager);
        return "prove_dorm_exchange_apply_list";
    }

    public String startOneEvaluation(){
        teacherAdminService.startEvaluation(courseId);
        return "start_one_Evaluation_success";
    }

    public String addCourse(){

        dataMap.put("success",true);

        Course course = new Course();
        course.setClassPlace(classPlace);
        course.setCourseInfo(courseInfo);
        course.setCourseName(courseName);
        course.setStartEvaluation(true);

        List<String> numberList = new ArrayList<>();

        for (String item :stuNumList.split("\n")){
            numberList.add(item.trim());
        }

        List<String> students = teacherAdminService.addCourse(course,teacherId,numberList);
        dataMap.put("students",students);

        return "json";
    }

    public String postCourse(){
        Course course = new Course();
        course.setClassPlace("2教105");
        course.setCourseInfo("12-14节");
        course.setCourseName("数字图像处理");
        course.setStartEvaluation(true);

        List<String> stuNumList = new ArrayList<>();
        stuNumList.add("111");
        stuNumList.add("222");

        teacherAdminService.addCourse(course,5,stuNumList);
        return "success";
    }

    public String postTeacher(){
        Teacher teacher = new Teacher();
        teacher.setName("丁墨恒");
        teacher.setPassword("22");
        teacher.setSex("女");
        teacher.setPhoneNumber("13580151262");
        teacherAdminService.addTeacher(teacher,2);
        return "success";

    }

    public String postDepartment(){

        Department department = new Department();
        department.setName("电气学院");
        department.setCode("dqxy");
        teacherAdminService.addDepartment(department);
        return "success";
    }

    public String postStudent(){
        Student student = new Student();
        student.setName("周浩杰");
        student.setGrade("2016");
        student.setPassword("123");
        student.setSex("男");
        student.setStudentCode("444");

        student.setUnit("计算机7班");

        teacherAdminService.addStudent(student,2,6);

        return "success";
    }

    public String postMajor(){
        Major major = new Major();


        major.setName("计算机科学与技术");
        major.setCode("48964869");
        teacherAdminService.addMajor(major,1);

        return "success";
    }



    public String proveClassroomApplyList(){
        Teacher curTeacher = (Teacher) session.get("curTeacher");
        Pager<ClassroomApplySheet> sheetPager = new Pager<>();
        sheetPager.setStart((Integer.valueOf(pg)-1)*10);
        sheetPager.setPageSize(10);
        List<ClassroomApplySheet> classroomApplySheetList = teacherAdminService.getProveClassroomApplyList(sheetPager);
        sheetPager.setTotalCount(((List) classroomApplySheetList).size());
        request.put("classroomApplySheetList",classroomApplySheetList);
        request.put("page",sheetPager);
        return "prove_classroom_apply_list";
    }

    public String proveClassroomApply(){

        Boolean actionResult = teacherAdminService.proveClassroomApply(sheetId,illustrate,(String)session.get("curUser"),String.valueOf(((Teacher)session.get("curTeacher")).getId()));
        return "prove_classroom_success";
    }


    public String disproveClassroomApply(){
        teacherAdminService.disproveClassroomApply(sheetId,illustrate,(Teacher)session.get("curTeacher"));
        return "disprove_classroom_apply_list";
    }

    public String proveDeviceApplyList(){
        Teacher curTeacher = (Teacher) session.get("curTeacher");
        Pager<DeviceApplySheet> sheetPager = new Pager<>();
        sheetPager.setStart((Integer.valueOf(pg)-1)*10);
        sheetPager.setPageSize(10);
        List<DeviceApplySheet> deviceApplySheetList = teacherAdminService.getProveDeviceApplyList(sheetPager);
        sheetPager.setTotalCount(((List) deviceApplySheetList).size());
        request.put("deviceApplySheetList",deviceApplySheetList);
        request.put("page",sheetPager);
        return "list";
    }

    public String proveDeviceApply(){

        if(voucherDate == null){
            Calendar calendar = new GregorianCalendar();
            calendar.setTime(new Date());
            calendar.add(calendar.DATE,3); //把日期往后增加一天,整数  往后推,负数往前移动
            voucherDate=calendar.getTime(); //这个时间就是日期往后推一天的结果
        }

        DeviceApplyReceiptSheet deviceApplyReceiptSheet = new DeviceApplyReceiptSheet();
        deviceApplyReceiptSheet.setIllustrate(illustrate);
        deviceApplyReceiptSheet.setResult("批准");
        deviceApplyReceiptSheet.setTeacherName((String)session.get("curUser"));
        deviceApplyReceiptSheet.setTeacherId(((Teacher)session.get("curTeacher")).getId());

        Boolean actionResult = teacherAdminService.proveDeviceApply(sheetId,voucherDate,illustrate,allowNum,deviceApplyReceiptSheet);
        return "prove_device_success";
    }

    public String disproveDeviceApply(){
        DeviceApplyReceiptSheet deviceApplyReceiptSheet = new DeviceApplyReceiptSheet();
        deviceApplyReceiptSheet.setResult("不批准");
        deviceApplyReceiptSheet.setTeacherName((String)session.get("curUser"));
        deviceApplyReceiptSheet.setTeacherId(((Teacher)session.get("curTeacher")).getId());
        teacherAdminService.disproveDeviceApply(sheetId,illustrate,deviceApplyReceiptSheet);
        return "prove_device_success";
    }

    public String studentList() {

        List<Student> students = studentService.getStudentList();
        request.put("students", students);

        return "student_list";
    }

    public String findStudent() {
        List<Student> students = studentService.findStudentList(name);
        request.put("students", students);

        return "student_list";

    }

    public String saveStudent(){
        Student student = new Student();
        student.setName(name);
        student.setSex(sex);
        student.setPassword(password);
        student.setStudentCode(studentCode);
        student.setUnit(unit);
        student.setGrade(grade);
        studentService.saveStudentList(student);

        return "success_student_add";
    }

        public String saveTeacher(){
        Teacher teacher = new Teacher();
        teacher.setName(name);
        teacher.setSex(sex);
        teacher.setPassword(password);
        teacher.setTeacherCode(teacherCode);
        teacher.setPhoneNumber(phoneNumber);
        teacher.setUnit(unit);
        teacher.setGrade(grade);
        teacherService.saveTeacherList(teacher);

        return "success_teacher_add";
    }

    public String saveWorker(){
        Worker worker = new Worker();
        worker.setName(name);

        workerService.saveWorkerList(worker);

        return "success_worker_add";
    }

    public String deleteStudent(){
        studentService.deleteStudentByID(id);
        dataMap.put("success",true);

        return "json";
    }

    public String editStudent(){

        Student student = studentService.getStudentById(id);
        request.put("student",student);

        return "student_edit";
    }

    public String updateStudent(){
        Student student = studentService.getStudentById(id);
        student.setName(name);
        student.setSex(sex);
        student.setStudentCode(studentCode);
        student.setUnit(unit);
        student.setGrade(grade);
        studentService.updateStudentByID(student);

        return "success_student_edit";
    }

    public String teacherList() {

        List<Teacher> teachers = teacherService.getTeacherList();
        request.put("teachers", teachers);

        return "teacher_list";
    }

    public String findTeacher() {
        List<Teacher> teachers = teacherService.findTeacherList(name);
        request.put("teachers", teachers);

        return "teacher_list";

    }

    public String deleteTeacher(){
        teacherService.deleteTeacherByID(id);
        dataMap.put("success",true);

        return "json";
    }

    public String editTeacher(){

        Teacher teacher = teacherService.getTeacherById(id);
        request.put("teacher",teacher);

        return "teacher_edit";
    }

    public String updateTeacher(){
        Teacher teacher = teacherService.getTeacherById(id);
        teacher.setName(name);
        teacher.setSex(sex);
        teacher.setTeacherCode(teacherCode);
        teacher.setPhoneNumber(phoneNumber);
        teacher.setUnit(unit);
        teacherService.updateTeacherByID(teacher);

        return "success_teacher_edit";
    }

    public String workerList() {

        List<Worker> workers = workerService.getWorkerList();
        request.put("workers", workers);

        return "worker_list";
    }

    public String findWorker() {
        List<Worker> workers = workerService.findWorkerList(name);
        request.put("workers", workers);

        return "worker_list";

    }

    public String deleteWorker(){
        workerService.deleteWorkerByID(id);
        dataMap.put("success",true);

        return "json";
    }

    public String editWorker(){

        Worker worker = workerService.getWorkerById(id);
        request.put("worker",worker);

        return "worker_edit";
    }

    public String updateWorker(){
        Worker worker = workerService.getWorkerById(id);
        worker.setName(name);

        workerService.updateWorkerByID(worker);

        return "success_worker_edit";
    }

    public String classroomMessageList() {

            List<ClassroomApplySheet> classroomApplySheets = studentService.getClassroomApplySheetList();
            request.put("classroomApplySheets", classroomApplySheets);

        return "classroom_list";
    }

        public String deviceMessageList() {

            List<DormExchangeSheet> dormExchangeSheets = studentService.getDormExchangeSheetList();
            request.put("dormExchangeSheets", dormExchangeSheets);

        return "device_list";
    }

        public String logisticsMessageList() {

            List<LogisticsRepairSheet> logisticsRepairSheets = studentService.getLogisticsRepairSheetList();
            request.put("logisticsRepairSheets", logisticsRepairSheets);

        return "logistics_list";
    }

    public String detail() {

        if (check.equals("classroom")){
            ClassroomApplySheet classroomApplySheet = studentService.getClassroomApplySheet(id);
            request.put("classroomApplySheet", classroomApplySheet);


        }
        if (check.equals("device")){
            DormExchangeSheet dormExchangeSheet = studentService.getDormExchangeSheet(id);
            request.put("dormExchangeSheet", dormExchangeSheet);


        }
        if (check.equals("logistics")){
            LogisticsRepairSheet logisticsRepairSheet = studentService.getLogisticsRepairSheet(id);
            Set<UploadFile> imgs = logisticsRepairSheet.getPictures();
            for(UploadFile img :imgs){
                request.put("picture", img.getNewName());
            }
            request.put("logisticsRepairSheet", logisticsRepairSheet);


        }

        return "success_detail";
    }






    public Integer getCourseId() {
        return courseId;
    }

    public void setCourseId(Integer courseId) {
        this.courseId = courseId;
    }

    public Integer getStuNum() {
        return StuNum;
    }

    public void setStuNum(Integer stuNum) {
        StuNum = stuNum;
    }

    @Override
    public void setRequest(Map<String, Object> request) {
        this.request = request;
    }

    public Date getVoucherDate() {
        return voucherDate;
    }

    public void setVoucherDate(Date voucherDate) {
        this.voucherDate = voucherDate;
    }

    public String getIllustrate() {
        return illustrate;
    }

    public void setIllustrate(String illustrate) {
        this.illustrate = illustrate;
    }

    public Integer getAllowNum() {
        return allowNum;
    }

    public void setAllowNum(Integer allowNum) {
        this.allowNum = allowNum;
    }

    public Integer getSheetId() {
        return sheetId;
    }

    public void setSheetId(Integer sheetId) {
        this.sheetId = sheetId;
    }

    public String getPg() {
        return pg;
    }

    public void setPg(String pg) {
        this.pg = pg;
    }

    @Override
    public void setSession(Map<String, Object> session) {
        this.session = session;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getStudentCode() {
        return studentCode;
    }

    public void setStudentCode(String studentCode) {
        this.studentCode = studentCode;
    }

    public Integer getSid() {
        return sid;
    }

    public void setSid(Integer sid) {
        this.sid = sid;
    }

    public String getTeacherCode() {
        return teacherCode;
    }

    public void setTeacherCode(String teacherCode) {
        this.teacherCode = teacherCode;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getCheck() {
        return check;
    }

    public void setCheck(String check) {
        this.check = check;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public String getClassPlace() {
        return classPlace;
    }

    public void setClassPlace(String classPlace) {
        this.classPlace = classPlace;
    }

    public String getCourseInfo() {
        return courseInfo;
    }

    public void setCourseInfo(String courseInfo) {
        this.courseInfo = courseInfo;
    }

    public String getStuNumList() {
        return stuNumList;
    }

    public void setStuNumList(String stuNumList) {
        this.stuNumList = stuNumList;
    }

    public Integer getTeacherId() {
        return teacherId;
    }

    public void setTeacherId(Integer teacherId) {
        this.teacherId = teacherId;
    }
}
