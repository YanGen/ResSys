package com.muhuan.actions;

import com.google.gson.*;
import com.muhuan.service.ElectricService;
import com.muhuan.utils.json.HistoryTradeBean;
import com.muhuan.utils.json.MapAreaIdBean;
import com.opensymphony.xwork2.ActionSupport;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.apache.struts2.interceptor.SessionAware;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * @author young
 * @ClassName: ElectricAction
 * @Description: TODO()
 * @date 2019/2/24 16:06
 */
@Controller
public class ElectricAction extends ActionSupport implements SessionAware {
    private static final long serialVersionUID = 1L;
    private Map<String ,Object> session;
    private Map<String ,Object> request;
    private Map<String ,Object> dataMap= new HashMap<>();
    private String repairArea1;
    private String repairArea2;
    private String repairArea3;
    private String repairArea4;
    @Autowired
    private ElectricService electricService;

    public String searchCurrent()throws Exception{
        dataMap.put("success",true);
        String architectureId = electricService.mapAreaId(repairArea3);
        if(architectureId != null){
            String roomId = electricService.mapRoomId(architectureId,repairArea4);
            if (roomId!=null){
                String result = electricService.searchCurrent(roomId);
                dataMap.put("current",result);

            }
        }
        return SUCCESS;

    }

    public String searchHistory(){
        dataMap.put("success",true);

        String architectureId = electricService.mapAreaId(repairArea3);
        if(architectureId != null){
            String roomId = electricService.mapRoomId(architectureId,repairArea4);
            if (roomId!=null){
                List<HistoryTradeBean> historyTrades = electricService.searchHistory(roomId);
                dataMap.put("historyTrades",historyTrades);

            }
        }
        return SUCCESS;

    }

    public Map<String, Object> getSession() {
        return session;
    }

    @Override
    public void setSession(Map<String, Object> session) {
        this.session = session;
    }

    public Map<String, Object> getRequest() {
        return request;
    }

    public void setRequest(Map<String, Object> request) {
        this.request = request;
    }

    public Map<String, Object> getDataMap() {
        return dataMap;
    }

    public void setDataMap(Map<String, Object> dataMap) {
        this.dataMap = dataMap;
    }

    public String getRepairArea1() {
        return repairArea1;
    }

    public void setRepairArea1(String repairArea1) {
        this.repairArea1 = repairArea1;
    }

    public String getRepairArea2() {
        return repairArea2;
    }

    public void setRepairArea2(String repairArea2) {
        this.repairArea2 = repairArea2;
    }

    public String getRepairArea3() {
        return repairArea3;
    }

    public void setRepairArea3(String repairArea3) {
        this.repairArea3 = repairArea3;
    }

    public String getRepairArea4() {
        return repairArea4;
    }

    public void setRepairArea4(String repairArea4) {
        this.repairArea4 = repairArea4;
    }
}
