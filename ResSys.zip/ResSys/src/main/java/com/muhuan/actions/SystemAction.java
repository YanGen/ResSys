package com.muhuan.actions;

import com.muhuan.model.basic.Dormitory;
import com.muhuan.model.school.Student;
import com.muhuan.model.school.Teacher;
import com.muhuan.service.SystemService;
import com.muhuan.utils.security.RsaUtil;
import com.opensymphony.xwork2.ActionSupport;
import org.apache.struts2.interceptor.RequestAware;
import org.apache.struts2.interceptor.SessionAware;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;

import java.security.KeyPair;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author young
 * @ClassName: SystemAction
 * @Description: TODO()
 * @date 2018/9/27 20:15
 */
@Controller("systemAction")
public class SystemAction extends ActionSupport implements SessionAware,RequestAware
{
    private static final long serialVersionUID = 1L;
    @Autowired
    private SystemService systemService;
    private Map<String ,Object> session;
    private Map<String ,Object> request;

    private String result;
    private String username;
    private String password;
    private String idtt;

    private Map<String,Object> dataMap = new HashMap<>();

    @Override
    public void setSession(Map<String, Object> session) {
        this.session = session;
    }

    public String tologinjson() throws Exception{
        dataMap.put("success",false);
        dataMap.put("to","/login.jsp");

        return SUCCESS;
    }

    public String teacherListJson() throws Exception{
        List<Teacher> teacherList = systemService.getTeacherList();
        dataMap.put("teacherList",teacherList);
        dataMap.put("success",true);
        return SUCCESS;
    }



    public String login() throws Exception{
        dataMap.put("success",true);

        session.put("teacherIsAdmin",false);
        if (! (result == null)){
            try {
                //私钥解密
                RSAPrivateKey rsaPrivateKey = (RSAPrivateKey) session.get("curPriKey");
                byte[] de_result = RsaUtil.decrypt(rsaPrivateKey,RsaUtil.hexStringToBytes(result));
                System.out.println("加密密文："+result);
                System.out.println("解密结果："+new StringBuffer(new String(de_result)).reverse().toString());

            }catch (Exception e){
                dataMap.put("success",false);
                dataMap.put("massage","本页面需要更新状态，请稍等！");
                dataMap.put("to","/systemloadkey.do");
                return SUCCESS;
            }

            //解密后账号密码验证
            List<Object> user = (List<Object>) systemService.userLoginCheck(username,password,idtt);

            if(user.size() != 0){
                session.put("loginMassage","已登录");
                session.put("curUser",username);
                session.put("curUserIdtt",idtt);

                if (idtt.equals("t2")){
//                    Student student = systemService.getStudentByCode(username);
                    Student student = (Student) user.get(0);
                    student.setPassword(null);
                    session.put("curStudent",student);
                    Dormitory dormitory = student.getDormitory();

                    if(dormitory != null){
                        String dormitoryString = dormitory.getBuilding().getName()+"-"+dormitory.getBuildingNumber()+"号-"+dormitory.getRoomNumber()+"房";

                        session.put("dormitoryString",dormitoryString);
                    }else {
                        session.put("dormitory",null);
                    }
                    dataMap.put("to","/index.jsp");
                }

//                如果是老师登录，判断是否为管理员
                if (idtt.equals("t3")){
                    Teacher teacher = (Teacher)user.get(0);
                    if(teacher.getTeacherIsAdmin()){
                        session.put("teacherIsAdmin",true);
                        dataMap.put("to","/model/teacher_admin/index.jsp");
                    }else {
                        dataMap.put("to","/model/teacher/index.jsp");
                    }
                    teacher.setPassword(null);
                    session.put("curTeacher",teacher);
                }
            }else {
                session.put("loginMassage","账号密码有误");
                dataMap.put("success",false);
                dataMap.put("massage","账号密码有误");
                return SUCCESS;
            }

            session.put("useRSA",null);
            session.put("curModulus",null);
            session.put("curExponent",null);
            session.put("curPriKey",null);

        }else{
            session.put("loginMassage","请求不合法");
            dataMap.put("success",false);
            dataMap.put("massage","请求不合法");
            dataMap.put("to","/systemloadkey.do");
        }

        return SUCCESS;
    }

    public String logout(){
        request.put("Massage","已退出~");
        session.put("user",null);
        session.put("curUser",null);
        session.put("curStudent",null);
        session.put("curTeacher",null);
        session.put("curUserIdtt",null);
        session.put("teacherIsAdmin",null);
        return "logout_success";
    }

    public String loadkey() throws Exception {
        KeyPair keyPair = RsaUtil.generateKeyPair();
        RSAPublicKey rsaPublicKey = (RSAPublicKey) keyPair.getPublic();
        RSAPrivateKey rsaPrivateKey = (RSAPrivateKey) keyPair.getPrivate();
        String Modulus = rsaPublicKey.getModulus().toString(16);
        String Exponent = rsaPublicKey.getPublicExponent().toString(16);
        session.put("curModulus", Modulus);
        session.put("curExponent", Exponent);
        session.put("useRSA", "noNull");
        session.put("curPriKey", rsaPrivateKey);
        if (idtt == null) {
            return "redirect_login_page";
        } else if (idtt.equals("t5")) {
            return "redirect_admin_login_page";
        }else {
            return "redirect_login_page";
    }

    }

    public Map<String, Object> getRequest() {
        return request;
    }

    @Override
    public void setRequest(Map<String, Object> request) {
        this.request = request;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getIdtt() {
        return idtt;
    }

    public void setIdtt(String idtt) {
        this.idtt = idtt;
    }

    public Map<String, Object> getDataMap() {
        return dataMap;
    }

    public void setDataMap(Map<String, Object> dataMap) {
        this.dataMap = dataMap;
    }
}
