package com.muhuan.dao;

import com.muhuan.dao.base.BaseDao;
import com.muhuan.model.flow.LogisticsRepairSheet;

import java.util.List;

/**
 * @author young
 * @ProjectName: ResSys
 * @Description: TODO()
 * @date 2018/12/17 19:25
 */
public interface LogisticsRepairSheetDao extends BaseDao<LogisticsRepairSheet> {
    List<LogisticsRepairSheet> workerRepairSheetList();
    List<LogisticsRepairSheet> teacherAdminRepairSheetList();
}
