package com.muhuan.dao;

import com.muhuan.dao.base.BaseDaoImpl;
import com.muhuan.model.basic.Device;
import org.springframework.stereotype.Repository;

/**
 * @author young
 * @ClassName: DeviceDaoImpl
 * @Description: TODO()
 * @date 2018/10/18 20:11
 */
@Repository("deviceDao")
public class DeviceDaoImpl extends BaseDaoImpl<Device> implements DeviceDao {
}
