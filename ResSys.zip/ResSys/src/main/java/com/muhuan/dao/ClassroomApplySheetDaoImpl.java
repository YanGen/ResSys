package com.muhuan.dao;

import com.muhuan.dao.base.BaseDaoImpl;
import com.muhuan.model.flow.ClassroomApplySheet;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public class ClassroomApplySheetDaoImpl extends BaseDaoImpl<ClassroomApplySheet> implements ClassroomApplySheetDao {
    @Override
    public List<ClassroomApplySheet> getByObject(ClassroomApplySheet classroomApplySheet) {
        return( List<ClassroomApplySheet>) getHibernateTemplate().findByExample(classroomApplySheet);
    }
}
