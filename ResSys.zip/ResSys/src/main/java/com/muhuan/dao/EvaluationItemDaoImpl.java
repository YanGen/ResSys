package com.muhuan.dao;

import com.muhuan.dao.base.BaseDaoImpl;
import com.muhuan.model.basic.EvaluationItem;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author young
 * @ProjectName: ResSys
 * @Description: TODO()
 * @date 2018/11/19 22:08
 */
@Repository
public class EvaluationItemDaoImpl extends BaseDaoImpl<EvaluationItem> implements EvaluationItemDao {
    @Override
    public List<EvaluationItem> getAll() {
        return (List<EvaluationItem>) getHibernateTemplate().find("from EvaluationItem");
    }
}
