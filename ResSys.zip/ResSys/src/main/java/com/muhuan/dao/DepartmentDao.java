package com.muhuan.dao;

import com.muhuan.dao.base.BaseDao;
import com.muhuan.model.school.Department;

/**
 * @author young
 * @ProjectName: ResSys
 * @Description: TODO()
 * @date 2018/11/18 19:13
 */
public interface DepartmentDao extends BaseDao<Department> {

}
