package com.muhuan.dao;

import com.muhuan.dao.base.BaseDaoImpl;
import com.muhuan.model.util.UploadFile;
import org.springframework.stereotype.Repository;

/**
 * @author young
 * @ProjectName: ResSys
 * @Description: TODO()
 * @date 2018/12/9 20:04
 */
@Repository
public class UploadFileDaoImpl extends BaseDaoImpl<UploadFile> implements UploadFileDao {
}
