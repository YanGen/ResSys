package com.muhuan.dao;

import com.muhuan.dao.base.BaseDao;
import com.muhuan.model.basic.EvaluationCard;
import org.springframework.stereotype.Repository;

/**
 * @author young
 * @ProjectName: ResSys
 * @Description: TODO()
 * @date 2018/11/19 12:44
 */
@Repository
public interface EvaluationCardDao extends BaseDao<EvaluationCard> {

}
