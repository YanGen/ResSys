package com.muhuan.dao;

import com.muhuan.dao.base.BaseDao;
import com.muhuan.model.school.Worker;

/**
 * @author young
 * @ProjectName: ResSys
 * @Description: TODO()
 * @date 2019/3/3 12:30
 */
public interface WorkerDao extends BaseDao<Worker> {
}

