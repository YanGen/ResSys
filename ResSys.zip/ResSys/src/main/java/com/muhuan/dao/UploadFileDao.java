package com.muhuan.dao;

import com.muhuan.dao.base.BaseDao;
import com.muhuan.model.util.UploadFile;

/**
 * @author young
 * @ProjectName: ResSys
 * @Description: TODO()
 * @date 2018/12/9 20:03
 */
public interface UploadFileDao extends BaseDao<UploadFile> {
}
