package com.muhuan.dao;

import com.muhuan.dao.base.BaseDao;
import com.muhuan.model.basic.Device;

/**
 * @author young
 * @ClassName: DeviceDao
 * @Description: TODO()
 * @date 2018/10/18 20:11
 */
public interface DeviceDao extends BaseDao<Device> {
}
