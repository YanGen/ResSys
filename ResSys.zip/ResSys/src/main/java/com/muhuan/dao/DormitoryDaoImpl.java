package com.muhuan.dao;

import com.muhuan.dao.base.BaseDaoImpl;
import com.muhuan.model.basic.Dormitory;
import com.muhuan.model.school.Building;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class DormitoryDaoImpl extends BaseDaoImpl<Dormitory> implements DormitoryDao {
    @Override
    public List<Dormitory> getByItem(String buildId, String buildNumber, String roomNumber) {
//        return (List<Dormitory>) getHibernateTemplate().find("from Dormitory d where d.building =? and d.buildingNumber =? and d.roomNumber =?",Integer.valueOf(buildId),buildNumber,roomNumber);
        Dormitory dormitory = new Dormitory();
        dormitory.setBuildingNumber(buildNumber);
        Building building = new Building();
        building.setId(Integer.valueOf(buildId));
        dormitory.setBuilding(building);
        dormitory.setRoomNumber(roomNumber);
        return (List<Dormitory>) getHibernateTemplate().findByExample(dormitory);

    }
}
