package com.muhuan.dao;

import com.muhuan.dao.base.BaseDaoImpl;
import com.muhuan.model.basic.Course;
import org.springframework.stereotype.Repository;

/**
 * @author young
 * @ProjectName: ResSys
 * @Description: TODO()
 * @date 2018/11/18 22:23
 */
@Repository
public class CourseDaoImpl extends BaseDaoImpl<Course> implements CourseDao {
}
