package com.muhuan.dao;

import com.muhuan.dao.base.BaseDaoImpl;
import com.muhuan.model.school.Building;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author young
 * @ProjectName: ResSys
 * @Description: TODO()
 * @date 2018/12/7 9:49
 */
@Repository
public class BuildingDaoImpl extends BaseDaoImpl<Building> implements BuildingDao {
    @Override
    public List<Building> getAll() {
        return (List<Building>) getHibernateTemplate().find("from Building");

    }
}
