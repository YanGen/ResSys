package com.muhuan.dao;

import com.muhuan.dao.base.BaseDao;
import com.muhuan.model.flow.DeviceApplyReceiptSheet;

/**
 * @author young
 * @ClassName: DeviceApplyReceiptSheetDao
 * @Description: TODO()
 * @date 2018/10/29 15:14
 */
public interface DeviceApplyReceiptSheetDao  extends BaseDao<DeviceApplyReceiptSheet> {
}
