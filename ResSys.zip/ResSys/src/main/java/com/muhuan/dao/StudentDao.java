package com.muhuan.dao;

import com.muhuan.dao.base.BaseDao;
import com.muhuan.model.school.Student;

/**
 * Created by young on 2018/9/24.
 */
public interface StudentDao extends BaseDao<Student> {
    public Student getByStudentNumber(String  studentNumber);
}
