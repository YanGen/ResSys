package com.muhuan.dao;

import com.muhuan.dao.base.BaseDaoImpl;
import com.muhuan.model.basic.EvaluationCard;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author young
 * @ProjectName: ResSys
 * @Description: TODO()
 * @date 2018/11/19 12:45
 */
@Repository
public class EvaluationCardDaoImpl extends BaseDaoImpl<EvaluationCard> implements EvaluationCardDao {

}
