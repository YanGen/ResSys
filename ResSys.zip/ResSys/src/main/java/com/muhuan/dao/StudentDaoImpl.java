package com.muhuan.dao;

import com.muhuan.dao.base.BaseDaoImpl;
import com.muhuan.model.school.Student;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by young on 2018/9/24.
 */
@Repository("studentDao")
public class StudentDaoImpl extends BaseDaoImpl<Student> implements StudentDao {
    @Override
    public Student getByStudentNumber(String studentNumber) {
        List<Student> s = (List<Student>) getHibernateTemplate().find("from Student s where s.studentCode=?", String.valueOf(studentNumber));
        if (s.size() == 0){
            return null;
        }
        return s.get(0);
    }
}
