package com.muhuan.dao;

import com.muhuan.dao.base.BaseDao;
import com.muhuan.model.school.Global;

import java.util.List;

/**
 * @author young
 * @ProjectName: ResSys
 * @Description: TODO()
 * @date 2019/4/12 14:41
 */
public interface GlobalDao extends BaseDao<Global> {

}
