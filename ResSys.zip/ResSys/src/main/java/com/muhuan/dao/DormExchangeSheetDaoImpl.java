package com.muhuan.dao;

import com.muhuan.dao.base.BaseDaoImpl;
import com.muhuan.model.flow.DormExchangeSheet;
import org.springframework.stereotype.Repository;

@Repository
public class DormExchangeSheetDaoImpl extends BaseDaoImpl<DormExchangeSheet> implements DormExchangeSheetDao {
}
