package com.muhuan.dao;

import com.muhuan.dao.base.BaseDao;
import com.muhuan.model.util.SchoolFile;

/**
 * @author young
 * @ProjectName: ResSys
 * @Description: TODO()
 * @date 2019/4/12 14:29
 */
public interface SchoolFileDao extends BaseDao<SchoolFile> {
}
