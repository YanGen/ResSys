package com.muhuan.dao;

import com.muhuan.dao.base.BaseDao;
import com.muhuan.model.basic.EvaluationItem;

import java.util.List;

/**
 * @author young
 * @ProjectName: ResSys
 * @Description: TODO()
 * @date 2018/11/19 22:07
 */
public interface EvaluationItemDao extends BaseDao<EvaluationItem> {

    /**
     * 获取所有
     * @return
     */

    List<EvaluationItem> getAll();
}
