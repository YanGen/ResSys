package com.muhuan.dao;

import com.muhuan.dao.base.BaseDaoImpl;
import com.muhuan.model.school.Teacher;
import org.springframework.stereotype.Repository;

/**
 * @author young
 * @ProjectName: ResSys
 * @Description: TODO()
 * @date 2018/11/18 22:02
 */
@Repository
public class TeacherDaoImpl extends BaseDaoImpl<Teacher> implements TeacherDao {
}
