package com.muhuan.dao;

import com.muhuan.dao.base.BaseDao;
import com.muhuan.model.school.Building;

import java.util.List;

/**
 * @author young
 * @ProjectName: ResSys
 * @Description: TODO()
 * @date 2018/12/7 9:48
 */
public interface BuildingDao extends BaseDao<Building> {
    public List<Building> getAll();
}
