package com.muhuan.dao;

import com.muhuan.dao.base.BaseDaoImpl;
import com.muhuan.model.util.SchoolFile;
import org.springframework.stereotype.Repository;

/**
 * @author young
 * @ProjectName: ResSys
 * @Description: TODO()
 * @date 2019/4/12 14:28
 */
@Repository
public class SchoolFileDaoImpl extends BaseDaoImpl<SchoolFile> implements SchoolFileDao {
}
