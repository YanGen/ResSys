package com.muhuan.dao;

import com.muhuan.dao.base.BaseDao;
import com.muhuan.model.basic.Course;

/**
 * @author young
 * @ProjectName: ResSys
 * @Description: TODO()
 * @date 2018/11/18 22:22
 */
public interface CourseDao extends BaseDao<Course> {
}
