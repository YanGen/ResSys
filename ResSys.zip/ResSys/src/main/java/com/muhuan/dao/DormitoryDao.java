package com.muhuan.dao;

import com.muhuan.dao.base.BaseDao;
import com.muhuan.model.basic.Dormitory;

import java.util.List;

public interface DormitoryDao extends BaseDao<Dormitory> {
    List<Dormitory> getByItem(String buildId, String buildNumber, String roomNumber);
}
