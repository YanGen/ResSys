package com.muhuan.dao;

import com.muhuan.dao.base.BaseDao;
import com.muhuan.model.flow.DeviceApplySheet;

import java.util.List;

/**
 * @author young
 * @ClassName: DeviceApplySheetDao
 * @Description: TODO()
 * @date 2018/10/25 21:37
 */
public interface DeviceApplySheetDao extends BaseDao<DeviceApplySheet> {
}
