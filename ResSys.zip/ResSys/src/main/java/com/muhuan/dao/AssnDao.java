package com.muhuan.dao;

import com.muhuan.dao.base.BaseDao;
import com.muhuan.model.basic.Assn;

/**
 * @author young
 * @ProjectName: ResSys
 * @Description: TODO()
 * @date 2019/3/1 11:06
 */
public interface AssnDao extends BaseDao<Assn> {
}