package com.muhuan.dao;

import com.muhuan.dao.base.BaseDaoImpl;
import com.muhuan.model.flow.LogisticsRepairSheet;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author young
 * @ProjectName: ResSys
 * @Description: TODO()
 * @date 2018/12/17 19:26
 */
@Repository
public class LogisticsRepairSheetDaoImpl extends BaseDaoImpl<LogisticsRepairSheet> implements LogisticsRepairSheetDao {
    @Override
    public List<LogisticsRepairSheet> workerRepairSheetList() {
        return (List<LogisticsRepairSheet>) getHibernateTemplate().find("from LogisticsRepairSheet s where s.systemProcessingTime is not null");
    }
    @Override
    public List<LogisticsRepairSheet> teacherAdminRepairSheetList() {
        return (List<LogisticsRepairSheet>) getHibernateTemplate().find("from LogisticsRepairSheet s where s.systemProcessingTime is null");
    }
}
