package com.muhuan.dao;

import com.muhuan.dao.base.BaseDao;
import com.muhuan.model.flow.DormExchangeSheet;

public interface DormExchangeSheetDao extends BaseDao<DormExchangeSheet> {
}
