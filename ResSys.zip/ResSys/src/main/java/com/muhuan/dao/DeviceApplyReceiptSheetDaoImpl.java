package com.muhuan.dao;

import com.muhuan.dao.base.BaseDaoImpl;
import com.muhuan.model.flow.DeviceApplyReceiptSheet;
import org.springframework.stereotype.Repository;

/**
 * @author young
 * @ClassName: DeviceApplyReceiptSheetDaoImpl
 * @Description: TODO()
 * @date 2018/10/29 15:15
 */
@Repository("deviceApplyReceiptSheetDao")
public class DeviceApplyReceiptSheetDaoImpl extends BaseDaoImpl<DeviceApplyReceiptSheet> implements DeviceApplyReceiptSheetDao {
}
