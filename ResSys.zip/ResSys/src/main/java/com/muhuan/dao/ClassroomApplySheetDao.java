package com.muhuan.dao;

import com.muhuan.dao.base.BaseDao;
import com.muhuan.model.flow.ClassroomApplySheet;

import java.util.List;

public interface ClassroomApplySheetDao extends BaseDao<ClassroomApplySheet> {
    List<ClassroomApplySheet> getByObject(ClassroomApplySheet classroomApplySheet);
}
