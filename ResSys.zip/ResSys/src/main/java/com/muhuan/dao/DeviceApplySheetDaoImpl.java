package com.muhuan.dao;

import com.muhuan.dao.base.BaseDaoImpl;
import com.muhuan.model.flow.DeviceApplySheet;
import org.springframework.stereotype.Repository;

import javax.management.Query;
import java.util.List;

/**
 * @author young
 * @ClassName: DeviceApplySheetDaoImpl
 * @Description: TODO()
 * @date 2018/10/25 21:36
 */
@Repository("deviceApplySheetDao")
public class DeviceApplySheetDaoImpl extends BaseDaoImpl<DeviceApplySheet> implements DeviceApplySheetDao {

}
